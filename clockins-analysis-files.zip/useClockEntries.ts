import { useQuery } from '@tanstack/react-query';
import {
  fetchClockEntriesRaw,
  fetchNextDayClockOuts,
  fetchProfileNames,
  fetchDaySchedulesForClock,
  fetchDayRequests,
} from '@/services/hrService';
import { format, startOfDay, endOfDay, addDays } from 'date-fns';
import type { ClockEntry, DayRequest, ScheduleInfo } from '@/components/local/clockins/types';

export function useClockEntries(
  branchId: string | undefined,
  date: Date,
  queryTag: string,
  refetchInterval?: number,
) {
  return useQuery({
    queryKey: ['clock-entries-grouped', queryTag, branchId, format(date, 'yyyy-MM-dd')],
    queryFn: async (): Promise<ClockEntry[]> => {
      const data = await fetchClockEntriesRaw(
        branchId!,
        startOfDay(date).toISOString(),
        endOfDay(date).toISOString(),
      );
      if (data.length === 0) return [];

      const byUser = new Map<string, typeof data>();
      for (const e of data) {
        const list = byUser.get(e.user_id) ?? [];
        list.push(e);
        byUser.set(e.user_id, list);
      }

      const filtered: typeof data = [];
      const usersNeedingNextDayOut: string[] = [];

      for (const [userId, userEntries] of byUser) {
        userEntries.sort(
          (a, b) => new Date(a.created_at!).getTime() - new Date(b.created_at!).getTime(),
        );

        let startIdx = 0;
        while (startIdx < userEntries.length && userEntries[startIdx].entry_type === 'clock_out') {
          startIdx++;
        }

        const remaining = userEntries.slice(startIdx);
        filtered.push(...remaining);

        if (remaining.length > 0 && remaining[remaining.length - 1].entry_type === 'clock_in') {
          usersNeedingNextDayOut.push(userId);
        }
      }

      const nextDayOuts: typeof data = [];
      if (usersNeedingNextDayOut.length > 0) {
        const nextDay = addDays(date, 1);
        const nextData = await fetchNextDayClockOuts(
          branchId!,
          usersNeedingNextDayOut,
          endOfDay(date).toISOString(),
          endOfDay(nextDay).toISOString(),
        );

        const seen = new Set<string>();
        for (const e of nextData) {
          if (!seen.has(e.user_id)) {
            seen.add(e.user_id);
            nextDayOuts.push(e);
          }
        }
      }

      const allEntries = [...filtered, ...nextDayOuts];

      const userIds = [...new Set(allEntries.map((e) => e.user_id))];
      if (userIds.length === 0) return [];

      const profileMap = await fetchProfileNames(userIds);
      const dayEnd = endOfDay(date).getTime();

      return allEntries.map((entry) => ({
        ...entry,
        entry_type: entry.entry_type as 'clock_in' | 'clock_out',
        created_at: entry.created_at!,
        user_name: profileMap.get(entry.user_id) || 'Usuario',
        isFromNextDay: new Date(entry.created_at!).getTime() > dayEnd,
      }));
    },
    enabled: !!branchId,
    refetchInterval,
  });
}

export function useDaySchedules(branchId: string | undefined, date: Date) {
  return useQuery({
    queryKey: ['day-schedules-for-clock', branchId, format(date, 'yyyy-MM-dd')],
    queryFn: async (): Promise<Map<string, ScheduleInfo[]>> => {
      const dateStr = format(date, 'yyyy-MM-dd');
      const rows = await fetchDaySchedulesForClock(branchId!, dateStr);

      const map = new Map<string, ScheduleInfo[]>();
      for (const row of rows) {
        const list = map.get(row.user_id) ?? [];
        list.push({
          start_time: row.start_time,
          end_time: row.end_time,
          is_day_off: row.is_day_off ?? false,
        });
        map.set(row.user_id, list);
      }

      for (const [uid, schedules] of map) {
        schedules.sort((a, b) => {
          const aMin = a.start_time ? parseInt(a.start_time.split(':')[0], 10) * 60 + parseInt(a.start_time.split(':')[1], 10) : 0;
          const bMin = b.start_time ? parseInt(b.start_time.split(':')[0], 10) * 60 + parseInt(b.start_time.split(':')[1], 10) : 0;
          return aMin - bMin;
        });
      }

      return map;
    },
    enabled: !!branchId,
  });
}

export function useDayRequests(branchId: string | undefined, date: Date) {
  return useQuery({
    queryKey: ['day-requests-for-clock', branchId, format(date, 'yyyy-MM-dd')],
    queryFn: async (): Promise<DayRequest[]> => {
      return fetchDayRequests(branchId!, format(date, 'yyyy-MM-dd'));
    },
    enabled: !!branchId,
  });
}
