import { differenceInMinutes, format } from 'date-fns';
import type {
  ClockEntry,
  DayRequest,
  RosterRow,
  RosterRowStatus,
  ScheduleInfo,
  SessionPair,
} from './types';

// ── Shared utilities ────────────────────────────────────────────────

function buildSessions(sorted: ClockEntry[]): { sessions: SessionPair[]; anomalies: string[] } {
  const sessions: SessionPair[] = [];
  const anomalies: string[] = [];
  let i = 0;

  while (i < sorted.length) {
    const cur = sorted[i];
    if (cur.entry_type === 'clock_in') {
      const next = sorted[i + 1];
      if (next && next.entry_type === 'clock_out') {
        sessions.push({
          clockIn: cur,
          clockOut: next,
          durationMin: differenceInMinutes(new Date(next.created_at), new Date(cur.created_at)),
        });
        i += 2;
      } else {
        sessions.push({ clockIn: cur, clockOut: null, durationMin: null });
        i += 1;
      }
    } else {
      anomalies.push(`Salida a las ${format(new Date(cur.created_at), 'HH:mm')} sin entrada previa`);
      sessions.push({ clockIn: null, clockOut: cur, durationMin: null });
      i += 1;
    }
  }
  return { sessions, anomalies };
}

function calcTotalMinutes(sessions: SessionPair[]): number {
  return sessions.reduce((sum, s) => {
    if (s.durationMin != null) return sum + s.durationMin;
    if (s.clockIn && !s.clockOut) {
      return sum + differenceInMinutes(new Date(), new Date(s.clockIn.created_at));
    }
    return sum;
  }, 0);
}

function timeToMinutes(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

function getDayRelation(dayDate: Date): 'past' | 'today' | 'future' {
  const d = new Date(dayDate);
  d.setHours(0, 0, 0, 0);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  if (d.getTime() > now.getTime()) return 'future';
  if (d.getTime() < now.getTime()) return 'past';
  return 'today';
}

export function formatDuration(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
}

function firstEntryTime(sessions: SessionPair[]): string | null {
  for (const s of sessions) {
    if (s.clockIn) return format(new Date(s.clockIn.created_at), 'HH:mm');
  }
  return null;
}

function lastExitTime(sessions: SessionPair[]): string | null {
  for (let i = sessions.length - 1; i >= 0; i--) {
    if (sessions[i].clockOut) return format(new Date(sessions[i].clockOut!.created_at), 'HH:mm');
  }
  return null;
}

// ── Shift assignment ────────────────────────────────────────────────

const UNMATCHED_THRESHOLD = 120; // 2 hours — sessions farther than this from any shift are "extra"

function assignSessionsToShifts(
  sessions: SessionPair[],
  schedules: ScheduleInfo[],
): { matched: Map<number, SessionPair[]>; unmatched: SessionPair[] } {
  const matched = new Map<number, SessionPair[]>();
  for (let i = 0; i < schedules.length; i++) matched.set(i, []);
  const unmatched: SessionPair[] = [];

  for (const session of sessions) {
    const ref = session.clockIn ?? session.clockOut;
    if (!ref) continue;

    const refMin = new Date(ref.created_at).getHours() * 60 + new Date(ref.created_at).getMinutes();

    let bestIdx = 0;
    let bestDist = Infinity;

    for (let i = 0; i < schedules.length; i++) {
      const sched = schedules[i];
      if (sched.is_day_off || !sched.start_time) continue;
      const dist = Math.abs(refMin - timeToMinutes(sched.start_time));
      if (dist < bestDist) { bestDist = dist; bestIdx = i; }
    }

    if (bestDist > UNMATCHED_THRESHOLD) {
      unmatched.push(session);
    } else {
      matched.get(bestIdx)!.push(session);
    }
  }

  return { matched, unmatched };
}

// ── Row builder ─────────────────────────────────────────────────────

const LATE_THRESHOLD = 10;

function resolveRowStatus(
  sessions: SessionPair[],
  schedule: ScheduleInfo | null,
  dayDate: Date,
  request: DayRequest | null,
): { status: RosterRowStatus; isLate: boolean; lateMinutes: number } {
  const hasSessions = sessions.length > 0;
  const lastSession = sessions[sessions.length - 1];
  const isCurrentlyIn = !!lastSession?.clockIn && !lastSession?.clockOut;
  const dayRelation = getDayRelation(dayDate);

  if (request) {
    return { status: hasSessions ? 'completed' : 'leave', isLate: false, lateMinutes: 0 };
  }

  if (!schedule) {
    if (!hasSessions) return { status: 'no_schedule', isLate: false, lateMinutes: 0 };
    return { status: isCurrentlyIn ? 'working' : 'completed', isLate: false, lateMinutes: 0 };
  }

  if (schedule.is_day_off) {
    return { status: 'day_off', isLate: false, lateMinutes: 0 };
  }

  if (!hasSessions) {
    if (dayRelation === 'future') {
      return { status: 'pending', isLate: false, lateMinutes: 0 };
    }
    if (dayRelation === 'today' && schedule.start_time) {
      const nowMin = new Date().getHours() * 60 + new Date().getMinutes();
      if (nowMin < timeToMinutes(schedule.start_time)) {
        return { status: 'pending', isLate: false, lateMinutes: 0 };
      }
    }
    return { status: 'absent', isLate: false, lateMinutes: 0 };
  }

  let isLate = false;
  let lateMinutes = 0;
  if (schedule.start_time) {
    const firstIn = sessions.find((s) => s.clockIn)?.clockIn;
    if (firstIn) {
      const actual = new Date(firstIn.created_at);
      const diff = (actual.getHours() * 60 + actual.getMinutes()) - timeToMinutes(schedule.start_time);
      if (diff > LATE_THRESHOLD) { isLate = true; lateMinutes = diff; }
    }
  }

  const status: RosterRowStatus = isLate ? 'late' : (isCurrentlyIn ? 'working' : 'completed');
  return { status, isLate, lateMinutes };
}

function shiftLabel(schedule: ScheduleInfo | null, request: DayRequest | null): string {
  if (request) {
    const labels: Record<string, string> = {
      sick_leave: 'Licencia', day_off: 'Día libre', vacation: 'Vacaciones', other: 'Licencia',
    };
    return labels[request.requestType] || request.requestType;
  }
  if (!schedule) return '—';
  if (schedule.is_day_off) return 'Franco';
  if (schedule.start_time && schedule.end_time) {
    return `${schedule.start_time.slice(0, 5)} - ${schedule.end_time.slice(0, 5)}`;
  }
  return '—';
}

function scheduledDurationMinutes(schedule: ScheduleInfo | null): number {
  if (!schedule?.start_time || !schedule?.end_time) return 0;
  const start = timeToMinutes(schedule.start_time);
  const end = timeToMinutes(schedule.end_time);
  if (end >= start) return end - start;
  // Overnight shift (e.g. 21:00 -> 02:00)
  return (24 * 60 - start) + end;
}

const STATUS_ORDER: Record<RosterRowStatus, number> = {
  absent: 0,
  late: 1,
  working: 2,
  pending: 3,
  completed: 4,
  day_off: 5,
  leave: 6,
  no_schedule: 7,
};

export function buildDayRoster(
  entries: ClockEntry[],
  scheduleMap: Map<string, ScheduleInfo[]>,
  staff: { userId: string; userName: string }[],
  requests: DayRequest[],
  dayDate: Date,
): RosterRow[] {
  const entriesByUser = new Map<string, ClockEntry[]>();
  for (const e of entries) {
    const list = entriesByUser.get(e.user_id) ?? [];
    list.push(e);
    entriesByUser.set(e.user_id, list);
  }

  const requestByUser = new Map<string, DayRequest>();
  for (const r of requests) requestByUser.set(r.userId, r);

  const allUserIds = new Set<string>();
  for (const s of staff) allUserIds.add(s.userId);
  for (const uid of entriesByUser.keys()) allUserIds.add(uid);
  for (const uid of scheduleMap.keys()) allUserIds.add(uid);

  const nameMap = new Map<string, string>();
  for (const s of staff) nameMap.set(s.userId, s.userName);
  for (const [uid, userEntries] of entriesByUser) {
    if (!nameMap.has(uid) && userEntries.length > 0) nameMap.set(uid, userEntries[0].user_name);
  }

  const rows: RosterRow[] = [];

  for (const userId of allUserIds) {
    const userEntries = entriesByUser.get(userId) ?? [];
    const schedules = scheduleMap.get(userId) ?? [];
    const request = requestByUser.get(userId) ?? null;
    const userName = nameMap.get(userId) || 'Usuario';

    if (schedules.length === 0 && userEntries.length === 0 && !request) continue;

    const sorted = [...userEntries].sort(
      (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime(),
    );
    const allSessions = buildSessions(sorted);

    const workSchedules = schedules.filter((s) => !s.is_day_off);
    const hasDayOff = schedules.some((s) => s.is_day_off);

    if (workSchedules.length === 0) {
      const sched = schedules[0] ?? null;
      const { status, isLate, lateMinutes } = resolveRowStatus(
        allSessions.sessions, sched, dayDate, request,
      );
      rows.push({
        rowKey: userId,
        userId,
        userName,
        isSubRow: false,
        status,
        shiftLabel: shiftLabel(sched, request),
        entryTime: firstEntryTime(allSessions.sessions),
        exitTime: lastExitTime(allSessions.sessions),
        totalMinutes: calcTotalMinutes(allSessions.sessions),
        isLate,
        lateMinutes,
        anomalies: allSessions.anomalies,
        sessions: allSessions.sessions,
        request,
        schedule: sched,
      });
      continue;
    }

    const { matched: sessionsByShift, unmatched: extraSessions } =
      assignSessionsToShifts(allSessions.sessions, workSchedules);

    let rowIdx = 0;

    // Extra sessions (employee came in outside any scheduled shift)
    if (extraSessions.length > 0) {
      const extraStatus = extraSessions.some((s) => s.clockIn && !s.clockOut) ? 'working' : 'completed';
      rows.push({
        rowKey: `${userId}-extra`,
        userId,
        userName,
        isSubRow: false,
        status: extraStatus as RosterRowStatus,
        shiftLabel: 'No programado',
        entryTime: firstEntryTime(extraSessions),
        exitTime: lastExitTime(extraSessions),
        totalMinutes: calcTotalMinutes(extraSessions),
        isLate: false,
        lateMinutes: 0,
        anomalies: [],
        sessions: extraSessions,
        request: null,
        schedule: null,
      });
      rowIdx++;
    }

    for (let i = 0; i < workSchedules.length; i++) {
      const sched = workSchedules[i];
      const shiftSessions = sessionsByShift.get(i) ?? [];
      const { status, isLate, lateMinutes } = resolveRowStatus(shiftSessions, sched, dayDate, request);
      const shiftAnomalies: string[] = [];

      if (!isLate && sched.start_time && shiftSessions.length > 0) {
        const firstIn = shiftSessions.find((s) => s.clockIn)?.clockIn;
        if (firstIn) {
          const actual = new Date(firstIn.created_at);
          const diff = (actual.getHours() * 60 + actual.getMinutes()) - timeToMinutes(sched.start_time);
          if (diff > 5 && diff <= LATE_THRESHOLD) {
            shiftAnomalies.push(`${diff} min tarde`);
          }
        }
      }

      const leaveWithoutClock = !!request && shiftSessions.length === 0;
      rows.push({
        rowKey: `${userId}-${i}`,
        userId,
        userName,
        isSubRow: rowIdx > 0,
        status,
        shiftLabel: shiftLabel(sched, null),
        entryTime: firstEntryTime(shiftSessions),
        exitTime: lastExitTime(shiftSessions),
        totalMinutes: leaveWithoutClock
          ? scheduledDurationMinutes(sched)
          : calcTotalMinutes(shiftSessions),
        isLate,
        lateMinutes,
        anomalies: shiftAnomalies,
        sessions: shiftSessions,
        request,
        schedule: sched,
      });
      rowIdx++;
    }
  }

  // Group rows by user, sort groups by highest-priority status, keep sub-rows together
  const groups = new Map<string, RosterRow[]>();
  const groupOrder: string[] = [];
  for (const row of rows) {
    if (!groups.has(row.userId)) {
      groups.set(row.userId, []);
      groupOrder.push(row.userId);
    }
    groups.get(row.userId)!.push(row);
  }

  const bestStatus = new Map<string, number>();
  for (const [uid, userRows] of groups) {
    bestStatus.set(uid, Math.min(...userRows.map((r) => STATUS_ORDER[r.status])));
  }

  groupOrder.sort((a, b) => {
    const so = bestStatus.get(a)! - bestStatus.get(b)!;
    if (so !== 0) return so;
    const nameA = groups.get(a)![0].userName;
    const nameB = groups.get(b)![0].userName;
    return nameA.localeCompare(nameB, 'es');
  });

  const sorted: RosterRow[] = [];
  for (const uid of groupOrder) {
    sorted.push(...groups.get(uid)!);
  }

  return sorted;
}
