export interface ClockEntry {
  id: string;
  entry_type: 'clock_in' | 'clock_out';
  created_at: string;
  user_id: string;
  user_name: string;
  photo_url?: string | null;
  gps_status?: string | null;
  is_manual?: boolean;
  manual_by?: string | null;
  manual_reason?: string | null;
  original_created_at?: string | null;
  isFromNextDay?: boolean;
}

export interface SessionPair {
  clockIn: ClockEntry | null;
  clockOut: ClockEntry | null;
  durationMin: number | null;
}

export interface ScheduleInfo {
  start_time: string | null;
  end_time: string | null;
  is_day_off: boolean;
}

export interface DayRequest {
  userId: string;
  requestType: string;
  status: string;
}

export type RosterRowStatus =
  | 'absent'
  | 'late'
  | 'working'
  | 'pending'
  | 'completed'
  | 'day_off'
  | 'leave'
  | 'no_schedule';

export interface RosterRow {
  rowKey: string;
  userId: string;
  userName: string;
  isSubRow: boolean;
  status: RosterRowStatus;
  shiftLabel: string;
  entryTime: string | null;
  exitTime: string | null;
  totalMinutes: number;
  isLate: boolean;
  lateMinutes: number;
  anomalies: string[];
  sessions: SessionPair[];
  request: DayRequest | null;
  schedule: ScheduleInfo | null;
}
