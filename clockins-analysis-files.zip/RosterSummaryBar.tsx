import type { RosterRow } from './types';

interface Props {
  rows: RosterRow[];
  isToday: boolean;
}

export function RosterSummaryBar({ rows, isToday }: Props) {
  const present = rows.filter((r) => ['working', 'late', 'completed'].includes(r.status)).length;
  const absent = rows.filter((r) => r.status === 'absent').length;
  const pending = rows.filter((r) => r.status === 'pending').length;
  const off = rows.filter((r) => ['day_off', 'leave'].includes(r.status)).length;

  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
      {present > 0 && (
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          {present} presente{present !== 1 ? 's' : ''}
        </span>
      )}
      {absent > 0 && (
        <span className="flex items-center gap-1.5 text-red-600 font-medium">
          <span className="w-2 h-2 rounded-full bg-red-500" />
          {absent} ausente{absent !== 1 ? 's' : ''}
        </span>
      )}
      {pending > 0 && (
        <span className="flex items-center gap-1.5 text-sky-600">
          <span className="w-2 h-2 rounded-full bg-sky-400" />
          {pending} pendiente{pending !== 1 ? 's' : ''}
        </span>
      )}
      {off > 0 && (
        <span className="flex items-center gap-1.5 text-muted-foreground">
          <span className="w-2 h-2 rounded-full bg-gray-400" />
          {off} franco/licencia
        </span>
      )}
      {isToday && (
        <span className="text-xs text-muted-foreground ml-auto">Auto-refresh cada 30s</span>
      )}
    </div>
  );
}
