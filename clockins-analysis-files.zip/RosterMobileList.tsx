import { useState, Fragment, useMemo } from 'react';
import { Stethoscope, ChevronDown, Camera } from 'lucide-react';
import type { ClockEntry } from './types';
import { formatDuration } from './helpers';
import { RosterExpandedRow } from './RosterExpandedRow';
import type { RosterRow, RosterRowStatus } from './types';

interface Props {
  rows: RosterRow[];
  branchId: string;
  selectedDate: Date;
  isToday: boolean;
  canEdit?: boolean;
  onMarkLeave?: (userId: string, userName: string) => void;
  onOpenPhotos?: (payload: { userName: string; shiftLabel: string; entries: ClockEntry[] }) => void;
  onEditEntry?: (entry: ClockEntry) => void;
  onDeleteEntry?: (entry: ClockEntry) => void;
}

const STATUS_COLOR: Record<RosterRowStatus, string> = {
  absent: 'text-red-600',
  late: 'text-amber-600',
  working: 'text-emerald-600',
  pending: 'text-sky-600',
  completed: 'text-muted-foreground',
  day_off: 'text-muted-foreground',
  leave: 'text-purple-600',
  no_schedule: 'text-muted-foreground',
};

const STATUS_LABEL: Record<RosterRowStatus, string> = {
  absent: 'Ausente',
  late: 'Tarde',
  working: 'En el local',
  pending: 'Pendiente',
  completed: 'Completado',
  day_off: 'Franco',
  leave: 'Licencia',
  no_schedule: 'Sin turno',
};

export function RosterMobileList({
  rows,
  branchId,
  selectedDate,
  isToday,
  canEdit,
  onMarkLeave,
  onOpenPhotos,
  onEditEntry,
  onDeleteEntry,
}: Props) {
  const [expandedUserId, setExpandedUserId] = useState<string | null>(null);

  const groupedRows = useMemo(() => {
    const groups: { userId: string; rows: RosterRow[] }[] = [];
    let current: { userId: string; rows: RosterRow[] } | null = null;

    for (const row of rows) {
      if (!row.isSubRow) {
        current = { userId: row.userId, rows: [row] };
        groups.push(current);
      } else if (current && current.userId === row.userId) {
        current.rows.push(row);
      } else {
        current = { userId: row.userId, rows: [row] };
        groups.push(current);
      }
    }
    return groups;
  }, [rows]);

  if (rows.length === 0) {
    return <p className="text-muted-foreground text-center py-8">No hay horarios ni fichajes registrados</p>;
  }

  return (
    <div className="divide-y">
      {groupedRows.map((group) => {
        const isExpanded = expandedUserId === group.userId;
        const mainRow = group.rows[0];

        return (
          <Fragment key={group.userId}>
            <div
              onClick={() => setExpandedUserId(isExpanded ? null : group.userId)}
              className="cursor-pointer active:bg-muted/60 transition-colors"
            >
              {/* Main row */}
              <div className="flex items-center gap-3 px-4 py-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm truncate">{mainRow.userName}</span>
                    <span className={`text-xs font-medium ${STATUS_COLOR[mainRow.status]}`}>
                      {STATUS_LABEL[mainRow.status]}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mt-0.5 text-xs text-muted-foreground">
                    <span className="font-mono">{mainRow.shiftLabel}</span>
                    {mainRow.entryTime && (
                      <span className={`font-mono ${mainRow.isLate ? 'text-amber-600' : ''}`}>
                        {mainRow.entryTime}{mainRow.exitTime ? ` → ${mainRow.exitTime}` : ''}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {mainRow.totalMinutes > 0 && (
                    <span className="text-sm font-mono font-medium">{formatDuration(mainRow.totalMinutes)}</span>
                  )}
                  {(() => {
                    const all = mainRow.sessions.flatMap((s) => [s.clockIn, s.clockOut].filter(Boolean)) as ClockEntry[];
                    const photos = all.filter((e) => !!e.photo_url);
                    if (!onOpenPhotos || photos.length === 0) return null;
                    return (
                      <button
                        onClick={(e) => { e.stopPropagation(); onOpenPhotos({ userName: mainRow.userName, shiftLabel: mainRow.shiftLabel, entries: photos }); }}
                        className="p-1 rounded text-muted-foreground"
                        title={`Ver fotos (${photos.length})`}
                      >
                        <Camera className="w-3.5 h-3.5" />
                      </button>
                    );
                  })()}
                  {canEdit && (mainRow.status === 'absent' || mainRow.status === 'pending') && onMarkLeave && (
                    <button
                      onClick={(e) => { e.stopPropagation(); onMarkLeave(mainRow.userId, mainRow.userName); }}
                      className="p-1 rounded text-purple-500"
                    >
                      <Stethoscope className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                </div>
              </div>

              {/* Sub-rows */}
              {group.rows.slice(1).map((row) => (
                <div key={row.rowKey} className="flex items-center gap-3 px-4 pb-2 pl-8">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>↳</span>
                      <span className="font-mono">{row.shiftLabel}</span>
                      {row.entryTime && (
                        <span className={`font-mono ${row.isLate ? 'text-amber-600' : ''}`}>
                          {row.entryTime}{row.exitTime ? ` → ${row.exitTime}` : ''}
                        </span>
                      )}
                      <span className={`font-medium ${STATUS_COLOR[row.status]}`}>
                        {STATUS_LABEL[row.status]}
                      </span>
                    </div>
                  </div>
                  {row.totalMinutes > 0 && (
                    <span className="text-xs font-mono flex-shrink-0">{formatDuration(row.totalMinutes)}</span>
                  )}
                </div>
              ))}
            </div>

            {isExpanded && (
              <RosterExpandedRow
                row={mainRow}
                branchId={branchId}
                selectedDate={selectedDate}
                canEdit={canEdit}
                onEditEntry={onEditEntry}
                onDeleteEntry={onDeleteEntry}
              />
            )}
          </Fragment>
        );
      })}
    </div>
  );
}
