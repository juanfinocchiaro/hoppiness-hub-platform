import { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, FileText, Building2 } from 'lucide-react';
import { useGastoMutations } from '@/hooks/useGastos';
import { useProveedores } from '@/hooks/useProveedores';
import { RdoCategorySelector, RdoCategoryBadge } from './RdoCategorySelector';
import { useRdoCategoryByCode } from '@/hooks/useRdoCategories';
import { CATEGORIA_GASTO_OPTIONS, MEDIO_PAGO_OPTIONS, getCurrentPeriodo } from '@/types/compra';
import type { Gasto } from '@/types/compra';

const ESTADO_OPTIONS = [
  { value: 'pagado', label: 'Pagado' },
  { value: 'pendiente', label: 'Pendiente de pago' },
];

interface GastoFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  branchId: string;
  gasto?: Gasto | null;
}

export function GastoFormModal({ open, onOpenChange, branchId, gasto }: GastoFormModalProps) {
  const { create, update } = useGastoMutations();
  const { data: proveedores } = useProveedores(branchId);
  const isEditing = !!gasto;

  const [form, setForm] = useState({
    fecha: new Date().toISOString().slice(0, 10),
    rdo_category_code: '',
    categoria_principal: '', // Legacy, se deriva del rdo_category
    proveedor_id: '',
    concepto: '',
    monto: '',
    estado: 'pagado',
    fecha_vencimiento: '',
    fecha_pago: '',
    medio_pago: 'efectivo',
    referencia_pago: '',
    observaciones: '',
  });

  // Obtener info de la categoría seleccionada
  const selectedCategory = useRdoCategoryByCode(form.rdo_category_code);

  useEffect(() => {
    if (open && gasto) {
      setForm({
        fecha: gasto.fecha,
        rdo_category_code: (gasto as any).rdo_category_code || '',
        categoria_principal: gasto.categoria_principal,
        proveedor_id: (gasto as any).proveedor_id || '',
        concepto: gasto.concepto,
        monto: String(gasto.monto),
        estado: gasto.estado || 'pagado',
        fecha_vencimiento: (gasto as any).fecha_vencimiento || '',
        fecha_pago: (gasto as any).fecha_pago || '',
        medio_pago: gasto.medio_pago || 'efectivo',
        referencia_pago: gasto.referencia_pago || '',
        observaciones: gasto.observaciones || '',
      });
    } else if (open) {
      setForm({
        fecha: new Date().toISOString().slice(0, 10),
        rdo_category_code: '',
        categoria_principal: '',
        proveedor_id: '',
        concepto: '',
        monto: '',
        estado: 'pagado',
        fecha_vencimiento: '',
        fecha_pago: new Date().toISOString().slice(0, 10),
        medio_pago: 'efectivo',
        referencia_pago: '',
        observaciones: '',
      });
    }
  }, [open, gasto]);

  // Derivar categoria_principal del rdo_category para compatibilidad
  const deriveCategoriaLegacy = (rdoCode: string): string => {
    if (!rdoCode) return 'varios';
    if (rdoCode.includes('alquiler') || rdoCode.includes('expensas')) return 'alquileres';
    if (rdoCode.includes('gas') || rdoCode.includes('energia') || rdoCode.includes('internet') || rdoCode.includes('agua')) return 'servicios';
    if (rdoCode.includes('sueldo') || rdoCode.includes('laboral') || rdoCode.includes('cargas')) return 'sueldos';
    if (rdoCode.includes('impuesto') || rdoCode.includes('iibb') || rdoCode.includes('iva')) return 'impuestos';
    if (rdoCode.includes('mantenimiento')) return 'mantenimiento';
    if (rdoCode.includes('marketing') || rdoCode.includes('fee')) return 'marketing';
    if (rdoCode.includes('logistica') || rdoCode.includes('delivery') || rdoCode.includes('flete')) return 'logistica';
    if (rdoCode.includes('software') || rdoCode.includes('contable') || rdoCode.includes('admin')) return 'administrativos';
    return 'varios';
  };

  const handleSubmit = async () => {
    if (!form.rdo_category_code || !form.concepto || !form.monto) return;

    const categoriaLegacy = deriveCategoriaLegacy(form.rdo_category_code);

    const payload: any = {
      branch_id: branchId,
      fecha: form.fecha,
      periodo: getCurrentPeriodo(),
      rdo_category_code: form.rdo_category_code,
      categoria_principal: categoriaLegacy,
      proveedor_id: form.proveedor_id || null,
      concepto: form.concepto,
      monto: parseFloat(form.monto),
      estado: form.estado,
      fecha_vencimiento: form.estado === 'pendiente' && form.fecha_vencimiento ? form.fecha_vencimiento : null,
      fecha_pago: form.estado === 'pagado' && form.fecha_pago ? form.fecha_pago : null,
      medio_pago: form.estado === 'pagado' ? form.medio_pago : null,
      referencia_pago: form.estado === 'pagado' ? (form.referencia_pago || null) : null,
      observaciones: form.observaciones || null,
    };

    if (isEditing) {
      await update.mutateAsync({ id: gasto.id, data: payload });
    } else {
      await create.mutateAsync(payload);
    }
    onOpenChange(false);
  };

  const set = (key: string, value: string) => setForm(f => ({ ...f, [key]: value }));
  const isPending = create.isPending || update.isPending;

  // Filtrar proveedores que dan servicios
  const proveedoresServicios = proveedores?.filter(p => 
    (p as any).tipo_proveedor?.includes('servicio') || 
    !(p as any).tipo_proveedor // Legacy: mostrar todos si no tiene tipo
  ) || proveedores || [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            {isEditing ? 'Editar Gasto/Servicio' : 'Registrar Gasto/Servicio'}
          </DialogTitle>
          <DialogDescription>
            Registra pagos de servicios como alquiler, luz, internet, contabilidad, etc.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Categoría RDO - Lo más importante */}
          <div className="space-y-2">
            <Label className="text-sm font-semibold flex items-center gap-2">
              Categoría del RDO *
              {selectedCategory && (
                <Badge variant={selectedCategory.behavior === 'variable' ? 'default' : 'secondary'} className="text-xs">
                  {selectedCategory.behavior === 'variable' ? 'Variable' : 'Fijo'}
                </Badge>
              )}
            </Label>
            <RdoCategorySelector
              value={form.rdo_category_code}
              onChange={(v) => set('rdo_category_code', v)}
              itemType="servicio"
              placeholder="¿En qué línea del RDO va este gasto?"
            />
            {selectedCategory?.description && (
              <p className="text-xs text-muted-foreground">{selectedCategory.description}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Fecha de factura *</Label>
              <Input type="date" value={form.fecha} onChange={e => set('fecha', e.target.value)} />
            </div>
            <div>
              <Label>Monto *</Label>
              <Input 
                type="number" 
                step="0.01" 
                value={form.monto} 
                onChange={e => set('monto', e.target.value)} 
                placeholder="$ 0.00"
              />
            </div>
          </div>

          {/* Proveedor opcional */}
          <div>
            <Label className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              Proveedor (opcional)
            </Label>
            <Select value={form.proveedor_id} onValueChange={v => set('proveedor_id', v)}>
              <SelectTrigger><SelectValue placeholder="Seleccionar proveedor..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value="">Sin proveedor específico</SelectItem>
                {proveedoresServicios.map(p => (
                  <SelectItem key={p.id} value={p.id}>{p.nombre}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Concepto / Descripción *</Label>
            <Input 
              value={form.concepto} 
              onChange={e => set('concepto', e.target.value)} 
              placeholder="Ej: Factura EPEC febrero 2026" 
            />
          </div>

          <Separator />

          {/* Estado de Pago */}
          <div>
            <Label className="text-sm font-semibold">Estado de Pago</Label>
            <Select value={form.estado} onValueChange={v => set('estado', v)}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {ESTADO_OPTIONS.map(e => (
                  <SelectItem key={e.value} value={e.value}>{e.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {form.estado === 'pendiente' && (
            <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <div className="flex items-center gap-2 text-yellow-800 text-sm font-medium mb-2">
                <AlertCircle className="h-4 w-4" />
                Pendiente de pago
              </div>
              <Label>Fecha de vencimiento</Label>
              <Input type="date" value={form.fecha_vencimiento} onChange={e => set('fecha_vencimiento', e.target.value)} />
            </div>
          )}

          {form.estado === 'pagado' && (
            <div className="space-y-3">
              <div>
                <Label>Fecha de pago</Label>
                <Input type="date" value={form.fecha_pago} onChange={e => set('fecha_pago', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Medio de Pago</Label>
                  <Select value={form.medio_pago} onValueChange={v => set('medio_pago', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {MEDIO_PAGO_OPTIONS.map(m => (
                        <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Referencia</Label>
                  <Input value={form.referencia_pago} onChange={e => set('referencia_pago', e.target.value)} placeholder="Nº comprobante" />
                </div>
              </div>
            </div>
          )}

          <div>
            <Label>Observaciones</Label>
            <Textarea value={form.observaciones} onChange={e => set('observaciones', e.target.value)} rows={2} />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button onClick={handleSubmit} disabled={isPending || !form.rdo_category_code || !form.concepto || !form.monto}>
              {isPending ? 'Guardando...' : isEditing ? 'Guardar Cambios' : 'Registrar Gasto'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}