-- =====================================================
-- SISTEMA DE CATEGORÍAS RDO (Resultado de Operaciones)
-- =====================================================
-- Este sistema unifica la categorización de todos los costos
-- para generar automáticamente el RDO/P&L

-- 1. TABLA MAESTRA DE CATEGORÍAS RDO
-- =====================================================
CREATE TABLE IF NOT EXISTS rdo_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,           -- Código único: 'cmv_hamburguesas'
  name text NOT NULL,                   -- Nombre display: 'CMV Hamburguesas'
  description text,                     -- Descripción de qué incluye
  
  -- Jerarquía
  parent_code text REFERENCES rdo_categories(code) ON DELETE SET NULL,
  level int NOT NULL DEFAULT 1,         -- 1=sección, 2=categoría, 3=subcategoría
  
  -- Clasificación
  rdo_section text NOT NULL CHECK (rdo_section IN (
    'ingresos',
    'costos_variables', 
    'costos_fijos',
    'financiacion',
    'impuestos'
  )),
  behavior text NOT NULL CHECK (behavior IN ('variable', 'fijo')),
  
  -- Tipo de items que acepta
  allowed_item_types text[] DEFAULT ARRAY['ingrediente', 'insumo', 'servicio'],
  
  -- Orden y display
  sort_order int NOT NULL DEFAULT 0,
  is_active boolean DEFAULT true,
  show_in_pl boolean DEFAULT true,      -- Si se muestra en el P&L
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Índices
CREATE INDEX idx_rdo_categories_parent ON rdo_categories(parent_code);
CREATE INDEX idx_rdo_categories_section ON rdo_categories(rdo_section);
CREATE INDEX idx_rdo_categories_sort ON rdo_categories(sort_order);

-- 2. INSERTAR CATEGORÍAS BASE DEL RDO
-- =====================================================
INSERT INTO rdo_categories (code, name, description, parent_code, level, rdo_section, behavior, allowed_item_types, sort_order) VALUES
-- COSTOS VARIABLES - Nivel 1 (Sección)
('costos_variables', 'COSTOS VARIABLES', 'Costos que escalan con las ventas', NULL, 1, 'costos_variables', 'variable', '{}', 100),

-- CMV - Nivel 2 (Categoría)
('cmv', 'Costo de Mercadería Vendida', 'Todo lo que consume el cliente', 'costos_variables', 2, 'costos_variables', 'variable', ARRAY['ingrediente'], 110),

-- CMV Subcategorías - Nivel 3
('cmv_hamburguesas', 'CMV Hamburguesas', 'Ingredientes de hamburguesas: carne, pan, quesos, salsas de cocina', 'cmv', 3, 'costos_variables', 'variable', ARRAY['ingrediente'], 111),
('cmv_bebidas_alcohol', 'Bebidas con Alcohol', 'Cervezas, vinos, spirits', 'cmv', 3, 'costos_variables', 'variable', ARRAY['ingrediente'], 112),
('cmv_bebidas_sin_alcohol', 'Bebidas sin Alcohol', 'Gaseosas, aguas, jugos', 'cmv', 3, 'costos_variables', 'variable', ARRAY['ingrediente'], 113),
('descartables_salon', 'Descartables Salón', 'Servilletas, cubiertos, vasos para salón', 'cmv', 3, 'costos_variables', 'variable', ARRAY['insumo'], 114),
('descartables_delivery', 'Descartables Delivery', 'Cajas, bolsas, contenedores para delivery', 'cmv', 3, 'costos_variables', 'variable', ARRAY['insumo'], 115),
('insumos_clientes', 'Insumos Clientes', 'Sobrecitos de salsas, maní, aderezos para llevar', 'cmv', 3, 'costos_variables', 'variable', ARRAY['insumo'], 116),

-- COMISIONES - Nivel 2
('comisiones', 'Comisiones por Venta', 'Comisiones de plataformas y medios de pago', 'costos_variables', 2, 'costos_variables', 'variable', ARRAY['servicio'], 120),
('comision_mp_point', 'Mercado Pago Point', 'Comisión por ventas con MP Point', 'comisiones', 3, 'costos_variables', 'variable', ARRAY['servicio'], 121),
('comision_mp_checkout', 'Mercado Pago Checkout', 'Comisión MP Checkout', 'comisiones', 3, 'costos_variables', 'variable', ARRAY['servicio'], 122),
('comision_mp_link', 'Mercado Pago Link', 'Comisión MP Link de Pago', 'comisiones', 3, 'costos_variables', 'variable', ARRAY['servicio'], 123),
('comision_mp_delivery', 'Mercado Pago Delivery', 'Comisión por ventas delivery con MP', 'comisiones', 3, 'costos_variables', 'variable', ARRAY['servicio'], 124),
('comision_rappi', 'Comisión Rappi', 'Comisión por ventas en Rappi', 'comisiones', 3, 'costos_variables', 'variable', ARRAY['servicio'], 125),
('comision_pedidosya', 'Comisión PedidosYa', 'Comisión por ventas en PedidosYa', 'comisiones', 3, 'costos_variables', 'variable', ARRAY['servicio'], 126),
('comision_masdelivery', 'Comisión MasDelivery', 'Comisión por ventas en MasDelivery', 'comisiones', 3, 'costos_variables', 'variable', ARRAY['servicio'], 127),

-- DELIVERY - Nivel 2
('delivery', 'Costos por Envío Delivery', 'Costos de entrega', 'costos_variables', 2, 'costos_variables', 'variable', ARRAY['servicio'], 130),
('cadetes_rappiboy', 'Cadetes RappiBoy', 'Pago a cadetes de Rappi', 'delivery', 3, 'costos_variables', 'variable', ARRAY['servicio'], 131),
('cadetes_terceros', 'Cadetes Terceros', 'Cadetes contratados vía WhatsApp u otros', 'delivery', 3, 'costos_variables', 'variable', ARRAY['servicio'], 132),

-- PUBLICIDAD Y MARCA - Nivel 2
('publicidad_marca', 'Publicidad y Marca', 'Fee de marca y marketing', 'costos_variables', 2, 'costos_variables', 'variable', ARRAY['servicio'], 140),
('fee_marca', 'Fee de Marca 4.5%', 'Canon/Fee de la franquicia', 'publicidad_marca', 3, 'costos_variables', 'variable', ARRAY['servicio'], 141),
('marketing', 'Marketing 0.5%', 'Fondo de marketing de la marca', 'publicidad_marca', 3, 'costos_variables', 'variable', ARRAY['servicio'], 142),

-- =====================================================
-- COSTOS FIJOS - Nivel 1
('costos_fijos', 'COSTOS FIJOS', 'Costos independientes del volumen de ventas', NULL, 1, 'costos_fijos', 'fijo', '{}', 200),

-- ESTRUCTURA OPERATIVA - Nivel 2
('estructura_operativa', 'Costos de Estructura Operativa', 'Gastos operativos del local', 'costos_fijos', 2, 'costos_fijos', 'fijo', ARRAY['insumo', 'servicio'], 210),
('limpieza_higiene', 'Limpieza e Higiene', 'Productos de limpieza, desinfectantes', 'estructura_operativa', 3, 'costos_fijos', 'fijo', ARRAY['insumo'], 211),
('descartables_cocina', 'Descartables Cocina', 'Descartables de uso interno (no cliente)', 'estructura_operativa', 3, 'costos_fijos', 'fijo', ARRAY['insumo'], 212),
('utiles_libreria', 'Útiles de Librería', 'Papelería, lapiceras, etc', 'estructura_operativa', 3, 'costos_fijos', 'fijo', ARRAY['insumo'], 213),
('mantenimiento_reparaciones', 'Mantenimiento y Reparaciones', 'Reparaciones y mantenimiento general', 'estructura_operativa', 3, 'costos_fijos', 'fijo', ARRAY['servicio', 'insumo'], 214),
('uniformes', 'Reposición de Uniformes', 'Uniformes del personal', 'estructura_operativa', 3, 'costos_fijos', 'fijo', ARRAY['insumo'], 215),
('fletes_locales', 'Fletes entre Locales', 'Préstamos de mercadería entre sucursales', 'estructura_operativa', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 216),
('abastecimiento', 'Servicios de Abastecimiento', 'Servicios de logística de proveedores', 'estructura_operativa', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 217),
('reservas_rappiboy', 'Reservas RappiBoy', 'Costo de reservas de cadetes', 'estructura_operativa', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 218),

-- COSTOS LABORALES - Nivel 2
('laborales', 'Costos Laborales', 'Sueldos y cargas sociales', 'costos_fijos', 2, 'costos_fijos', 'fijo', ARRAY['servicio'], 220),
('sueldos', 'Sueldos', 'Sueldos de bolsillo', 'laborales', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 221),
('cargas_sociales', 'Cargas Sociales', 'Aportes y contribuciones', 'laborales', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 222),
('comida_personal', 'Comida Personal (ESPECHE)', 'Viandas del personal', 'laborales', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 223),
('otros_personal', 'Otros Gastos de Personal', 'ART, seguros, etc', 'laborales', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 224),

-- ADMINISTRACIÓN Y GESTIÓN - Nivel 2
('administracion', 'Administración y Gestión', 'Gastos administrativos', 'costos_fijos', 2, 'costos_fijos', 'fijo', ARRAY['servicio'], 230),
('software_gestion', 'Software de Gestión', 'Sistemas, apps, subscripciones IT', 'administracion', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 231),
('estudio_contable', 'Estudio Contable', 'Honorarios del contador', 'administracion', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 232),
('admin_interna', 'Administración Interna', 'Honorarios administración propia', 'administracion', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 233),
('bromatologia', 'Bromatología', 'Análisis y habilitaciones', 'administracion', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 234),

-- SERVICIOS E INFRAESTRUCTURA - Nivel 2
('servicios_infra', 'Servicios e Infraestructura', 'Servicios básicos y alquiler', 'costos_fijos', 2, 'costos_fijos', 'fijo', ARRAY['servicio'], 240),
('alquiler', 'Alquiler', 'Alquiler mensual del local', 'servicios_infra', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 241),
('expensas', 'Gastos Comunes / Expensas', 'Expensas del edificio', 'servicios_infra', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 242),
('gas', 'Gas (ECOGAS)', 'Servicio de gas', 'servicios_infra', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 243),
('internet_telefonia', 'Internet / Telefonía', 'Internet y teléfono', 'servicios_infra', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 244),
('energia_electrica', 'Energía Eléctrica (EPEC)', 'Servicio de luz', 'servicios_infra', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 245),
('agua', 'Agua', 'Servicio de agua', 'servicios_infra', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 246),
('seguro_local', 'Seguro del Local', 'Póliza de seguro', 'servicios_infra', 3, 'costos_fijos', 'fijo', ARRAY['servicio'], 247),

-- =====================================================
-- FINANCIACIÓN - Nivel 1
('financiacion', 'FINANCIACIÓN', 'Costos financieros', NULL, 1, 'financiacion', 'fijo', '{}', 300),
('intereses', 'Intereses', 'Intereses de préstamos y financiación', 'financiacion', 2, 'financiacion', 'fijo', ARRAY['servicio'], 310),

-- =====================================================
-- IMPUESTOS - Nivel 1
('impuestos', 'IMPUESTOS', 'Impuestos y tasas', NULL, 1, 'impuestos', 'fijo', '{}', 400),
('comercio_industria', 'Comercio e Industria', 'Tasa municipal', 'impuestos', 2, 'impuestos', 'fijo', ARRAY['servicio'], 410),
('debitos_creditos', 'Imp. Débitos y Créditos', 'Impuesto al cheque', 'impuestos', 2, 'impuestos', 'fijo', ARRAY['servicio'], 420),
('iibb', 'Ingresos Brutos', 'IIBB provincial', 'impuestos', 2, 'impuestos', 'fijo', ARRAY['servicio'], 430),
('iva_no_computable', 'IVA No Computable', 'IVA que no se puede descontar', 'impuestos', 2, 'impuestos', 'fijo', ARRAY['servicio'], 440)

ON CONFLICT (code) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  sort_order = EXCLUDED.sort_order;


-- 3. AGREGAR TIPO DE ITEM A INSUMOS
-- =====================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'insumos' AND column_name = 'tipo_item') THEN
    ALTER TABLE insumos ADD COLUMN tipo_item text DEFAULT 'insumo' CHECK (tipo_item IN ('ingrediente', 'insumo'));
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'insumos' AND column_name = 'rdo_category_code') THEN
    ALTER TABLE insumos ADD COLUMN rdo_category_code text REFERENCES rdo_categories(code);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'insumos' AND column_name = 'tracks_stock') THEN
    ALTER TABLE insumos ADD COLUMN tracks_stock boolean DEFAULT false;
  END IF;
END $$;

-- Índice para búsqueda por tipo
CREATE INDEX IF NOT EXISTS idx_insumos_tipo ON insumos(tipo_item);
CREATE INDEX IF NOT EXISTS idx_insumos_rdo_category ON insumos(rdo_category_code);


-- 4. AGREGAR CATEGORÍA RDO A GASTOS
-- =====================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'gastos' AND column_name = 'rdo_category_code') THEN
    ALTER TABLE gastos ADD COLUMN rdo_category_code text REFERENCES rdo_categories(code);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'gastos' AND column_name = 'proveedor_id') THEN
    ALTER TABLE gastos ADD COLUMN proveedor_id uuid REFERENCES proveedores(id);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_gastos_rdo_category ON gastos(rdo_category_code);


-- 5. AGREGAR CATEGORÍA RDO A ITEMS DE FACTURA
-- =====================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'items_factura' AND column_name = 'rdo_category_code') THEN
    ALTER TABLE items_factura ADD COLUMN rdo_category_code text REFERENCES rdo_categories(code);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_items_factura_rdo_category ON items_factura(rdo_category_code);


-- 6. AGREGAR TIPO A PROVEEDORES
-- =====================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'proveedores' AND column_name = 'tipo_proveedor') THEN
    ALTER TABLE proveedores ADD COLUMN tipo_proveedor text[] DEFAULT ARRAY['insumo'];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'proveedores' AND column_name = 'rdo_categories_default') THEN
    ALTER TABLE proveedores ADD COLUMN rdo_categories_default text[];
  END IF;
END $$;


-- 7. VISTA PARA GENERAR EL RDO
-- =====================================================
CREATE OR REPLACE VIEW rdo_report_data AS
WITH 
-- Gastos directos por categoría RDO
gastos_por_categoria AS (
  SELECT 
    g.branch_id,
    g.periodo,
    g.rdo_category_code,
    SUM(g.monto) as total_gastos
  FROM gastos g
  WHERE g.deleted_at IS NULL
    AND g.rdo_category_code IS NOT NULL
  GROUP BY g.branch_id, g.periodo, g.rdo_category_code
),

-- Items de factura por categoría RDO
compras_por_categoria AS (
  SELECT 
    fp.branch_id,
    fp.periodo,
    COALESCE(it.rdo_category_code, i.rdo_category_code) as rdo_category_code,
    SUM(it.subtotal) as total_compras
  FROM items_factura it
  JOIN facturas_proveedores fp ON fp.id = it.factura_id
  LEFT JOIN insumos i ON i.id = it.insumo_id
  WHERE fp.deleted_at IS NULL
    AND COALESCE(it.rdo_category_code, i.rdo_category_code) IS NOT NULL
  GROUP BY fp.branch_id, fp.periodo, COALESCE(it.rdo_category_code, i.rdo_category_code)
),

-- Unión de todos los costos
all_costs AS (
  SELECT branch_id, periodo, rdo_category_code, total_gastos as monto FROM gastos_por_categoria
  UNION ALL
  SELECT branch_id, periodo, rdo_category_code, total_compras as monto FROM compras_por_categoria
)

SELECT 
  ac.branch_id,
  ac.periodo,
  rc.code as category_code,
  rc.name as category_name,
  rc.parent_code,
  rc.level,
  rc.rdo_section,
  rc.behavior,
  rc.sort_order,
  SUM(ac.monto) as total
FROM all_costs ac
JOIN rdo_categories rc ON rc.code = ac.rdo_category_code
WHERE rc.is_active = true
GROUP BY 
  ac.branch_id, 
  ac.periodo, 
  rc.code, 
  rc.name, 
  rc.parent_code, 
  rc.level,
  rc.rdo_section,
  rc.behavior,
  rc.sort_order
ORDER BY rc.sort_order;


-- 8. FUNCIÓN PARA OBTENER RDO COMPLETO CON JERARQUÍA
-- =====================================================
CREATE OR REPLACE FUNCTION get_rdo_report(
  p_branch_id uuid,
  p_periodo text
)
RETURNS TABLE (
  category_code text,
  category_name text,
  parent_code text,
  level int,
  rdo_section text,
  behavior text,
  sort_order int,
  total numeric,
  percentage numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_total_ingresos numeric;
BEGIN
  -- Obtener total de ingresos del período (de ventas_mensuales u otra fuente)
  SELECT COALESCE(SUM(vm.total_facturado), 0) INTO v_total_ingresos
  FROM ventas_mensuales vm
  WHERE vm.branch_id = p_branch_id 
    AND to_char(vm.fecha, 'YYYY-MM') = p_periodo;
  
  -- Si no hay ingresos, usar 1 para evitar división por cero
  IF v_total_ingresos = 0 THEN
    v_total_ingresos := 1;
  END IF;

  RETURN QUERY
  WITH category_totals AS (
    SELECT 
      r.category_code,
      r.category_name,
      r.parent_code,
      r.level,
      r.rdo_section,
      r.behavior,
      r.sort_order,
      COALESCE(r.total, 0) as total
    FROM rdo_report_data r
    WHERE r.branch_id = p_branch_id
      AND r.periodo = p_periodo
  ),
  all_categories AS (
    SELECT 
      rc.code as category_code,
      rc.name as category_name,
      rc.parent_code,
      rc.level,
      rc.rdo_section,
      rc.behavior,
      rc.sort_order,
      COALESCE(ct.total, 0) as total
    FROM rdo_categories rc
    LEFT JOIN category_totals ct ON ct.category_code = rc.code
    WHERE rc.is_active = true
      AND rc.show_in_pl = true
  )
  SELECT 
    ac.category_code,
    ac.category_name,
    ac.parent_code,
    ac.level,
    ac.rdo_section,
    ac.behavior,
    ac.sort_order,
    ac.total,
    ROUND((ac.total / v_total_ingresos * 100)::numeric, 2) as percentage
  FROM all_categories ac
  ORDER BY ac.sort_order;
END;
$$;


-- 9. RLS PARA rdo_categories (lectura pública para autenticados)
-- =====================================================
ALTER TABLE rdo_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "rdo_categories_select_authenticated" ON rdo_categories
  FOR SELECT TO authenticated
  USING (true);

-- Solo superadmin puede modificar categorías
CREATE POLICY "rdo_categories_all_superadmin" ON rdo_categories
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles_v2 
      WHERE user_id = auth.uid() 
      AND brand_role = 'superadmin' 
      AND is_active = true
    )
  );


-- 10. TRIGGER PARA ACTUALIZAR updated_at
-- =====================================================
CREATE OR REPLACE FUNCTION update_rdo_categories_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_rdo_categories_updated_at ON rdo_categories;
CREATE TRIGGER trg_rdo_categories_updated_at
  BEFORE UPDATE ON rdo_categories
  FOR EACH ROW
  EXECUTE FUNCTION update_rdo_categories_updated_at();


-- 11. COMENTARIOS PARA DOCUMENTACIÓN
-- =====================================================
COMMENT ON TABLE rdo_categories IS 'Categorías del RDO (Resultado de Operaciones). Estructura jerárquica para clasificar todos los costos.';
COMMENT ON COLUMN rdo_categories.code IS 'Código único de la categoría, usado como identificador en todo el sistema';
COMMENT ON COLUMN rdo_categories.behavior IS 'variable = escala con ventas, fijo = monto constante';
COMMENT ON COLUMN rdo_categories.allowed_item_types IS 'Tipos de items que pueden usar esta categoría: ingrediente, insumo, servicio';
COMMENT ON COLUMN insumos.tipo_item IS 'ingrediente = lo que se come el cliente, insumo = descartables y operativos';
COMMENT ON COLUMN insumos.rdo_category_code IS 'Categoría RDO por defecto para este insumo';
COMMENT ON COLUMN insumos.tracks_stock IS 'Si se controla stock de este insumo';
