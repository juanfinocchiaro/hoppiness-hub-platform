// =====================================================
// TIPOS PARA SISTEMA RDO (Resultado de Operaciones)
// =====================================================

export type RdoSection = 
  | 'ingresos'
  | 'costos_variables'
  | 'costos_fijos'
  | 'financiacion'
  | 'impuestos';

export type CostBehavior = 'variable' | 'fijo';

export type ItemType = 'ingrediente' | 'insumo' | 'servicio';

// Categoría RDO de la base de datos
export interface RdoCategory {
  id: string;
  code: string;
  name: string;
  description: string | null;
  parent_code: string | null;
  level: number;
  rdo_section: RdoSection;
  behavior: CostBehavior;
  allowed_item_types: ItemType[];
  sort_order: number;
  is_active: boolean;
  show_in_pl: boolean;
  created_at: string;
  updated_at: string;
}

// Categoría con hijos (para árbol jerárquico)
export interface RdoCategoryWithChildren extends RdoCategory {
  children: RdoCategoryWithChildren[];
}

// Línea del reporte RDO
export interface RdoReportLine {
  category_code: string;
  category_name: string;
  parent_code: string | null;
  level: number;
  rdo_section: RdoSection;
  behavior: CostBehavior;
  sort_order: number;
  total: number;
  percentage: number;
}

// Reporte RDO completo estructurado
export interface RdoReport {
  periodo: string;
  branch_id: string;
  ingresos: {
    total: number;
    lines: RdoReportLine[];
  };
  costos_variables: {
    total: number;
    percentage: number;
    lines: RdoReportLine[];
    subtotals: {
      cmv: number;
      comisiones: number;
      delivery: number;
      publicidad_marca: number;
    };
  };
  costos_fijos: {
    total: number;
    percentage: number;
    lines: RdoReportLine[];
    subtotals: {
      estructura_operativa: number;
      laborales: number;
      administracion: number;
      servicios_infra: number;
    };
  };
  resultado_operativo: {
    ebit: number;
    percentage: number;
  };
  financiacion: {
    total: number;
    percentage: number;
    lines: RdoReportLine[];
  };
  impuestos: {
    total: number;
    percentage: number;
    lines: RdoReportLine[];
  };
  resultado_neto: {
    total: number;
    percentage: number;
  };
}

// =====================================================
// TIPOS PARA INSUMOS EXTENDIDOS
// =====================================================

export interface InsumoExtended {
  id: string;
  nombre: string;
  descripcion: string | null;
  tipo_item: ItemType;
  rdo_category_code: string | null;
  rdo_category?: RdoCategory;
  unidad_base: string;
  tracks_stock: boolean;
  precio_referencia: number | null;
  precio_maximo_sugerido: number | null;
  proveedor_sugerido_id: string | null;
  proveedor_obligatorio_id: string | null;
  nivel_control: string;
  activo: boolean;
  created_at: string;
}

export interface InsumoFormData {
  nombre: string;
  descripcion?: string;
  tipo_item: ItemType;
  rdo_category_code: string;
  unidad_base: string;
  tracks_stock: boolean;
  precio_referencia?: number;
  precio_maximo_sugerido?: number;
  proveedor_sugerido_id?: string;
  proveedor_obligatorio_id?: string;
  nivel_control: string;
}

// =====================================================
// TIPOS PARA PROVEEDORES EXTENDIDOS
// =====================================================

export interface ProveedorExtended {
  id: string;
  nombre: string;
  cuit: string | null;
  telefono: string | null;
  email: string | null;
  direccion: string | null;
  tipo_proveedor: ItemType[];
  rdo_categories_default: string[];
  condicion_pago_default: string | null;
  notas: string | null;
  activo: boolean;
  branch_id: string;
  created_at: string;
}

export interface ProveedorFormData {
  nombre: string;
  cuit?: string;
  telefono?: string;
  email?: string;
  direccion?: string;
  tipo_proveedor: ItemType[];
  rdo_categories_default?: string[];
  condicion_pago_default?: string;
  notas?: string;
  branch_id: string;
}

// =====================================================
// TIPOS PARA GASTOS EXTENDIDOS
// =====================================================

export interface GastoExtended {
  id: string;
  branch_id: string;
  fecha: string;
  periodo: string;
  rdo_category_code: string | null;
  rdo_category?: RdoCategory;
  proveedor_id: string | null;
  proveedor?: ProveedorExtended;
  concepto: string;
  monto: number;
  estado: string | null;
  fecha_vencimiento: string | null;
  fecha_pago: string | null;
  medio_pago: string | null;
  referencia_pago: string | null;
  observaciones: string | null;
  created_at: string;
  // Campos legacy para compatibilidad
  categoria_principal: string;
  subcategoria: string | null;
}

export interface GastoFormDataExtended {
  branch_id: string;
  fecha: string;
  periodo: string;
  rdo_category_code: string;
  proveedor_id?: string;
  concepto: string;
  monto: number;
  estado?: string;
  fecha_vencimiento?: string;
  fecha_pago?: string;
  medio_pago?: string;
  referencia_pago?: string;
  observaciones?: string;
  // Para compatibilidad, derivamos de rdo_category
  categoria_principal?: string;
  subcategoria?: string;
}

// =====================================================
// CONSTANTES
// =====================================================

export const ITEM_TYPE_OPTIONS: { value: ItemType; label: string; description: string }[] = [
  { 
    value: 'ingrediente', 
    label: 'Ingrediente', 
    description: 'Lo que se come el cliente (carne, pan, quesos, bebidas)' 
  },
  { 
    value: 'insumo', 
    label: 'Insumo', 
    description: 'Descartables, limpieza, sobrecitos para clientes' 
  },
  { 
    value: 'servicio', 
    label: 'Servicio', 
    description: 'Pagos recurrentes (alquiler, luz, internet, contador)' 
  },
];

export const RDO_SECTION_LABELS: Record<RdoSection, string> = {
  ingresos: 'Ingresos',
  costos_variables: 'Costos Variables',
  costos_fijos: 'Costos Fijos',
  financiacion: 'Financiación',
  impuestos: 'Impuestos',
};

export const BEHAVIOR_LABELS: Record<CostBehavior, string> = {
  variable: 'Variable (escala con ventas)',
  fijo: 'Fijo (monto constante)',
};

// Función helper para obtener el ícono según tipo
export function getItemTypeIcon(type: ItemType): string {
  switch (type) {
    case 'ingrediente': return '🍔';
    case 'insumo': return '📦';
    case 'servicio': return '📋';
    default: return '❓';
  }
}

// Función helper para obtener color según sección RDO
export function getRdoSectionColor(section: RdoSection): string {
  switch (section) {
    case 'ingresos': return 'bg-green-100 text-green-800';
    case 'costos_variables': return 'bg-orange-100 text-orange-800';
    case 'costos_fijos': return 'bg-blue-100 text-blue-800';
    case 'financiacion': return 'bg-purple-100 text-purple-800';
    case 'impuestos': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
}

// Función para construir árbol de categorías
export function buildCategoryTree(categories: RdoCategory[]): RdoCategoryWithChildren[] {
  const map = new Map<string, RdoCategoryWithChildren>();
  const roots: RdoCategoryWithChildren[] = [];

  // Crear mapa con children vacíos
  categories.forEach(cat => {
    map.set(cat.code, { ...cat, children: [] });
  });

  // Construir árbol
  categories.forEach(cat => {
    const node = map.get(cat.code)!;
    if (cat.parent_code && map.has(cat.parent_code)) {
      map.get(cat.parent_code)!.children.push(node);
    } else if (!cat.parent_code || cat.level === 1) {
      roots.push(node);
    }
  });

  // Ordenar hijos por sort_order
  const sortChildren = (nodes: RdoCategoryWithChildren[]) => {
    nodes.sort((a, b) => a.sort_order - b.sort_order);
    nodes.forEach(n => sortChildren(n.children));
  };
  sortChildren(roots);

  return roots;
}

// Función para aplanar categorías con indentación
export function flattenCategoriesForSelect(
  categories: RdoCategory[],
  filterByItemType?: ItemType
): { value: string; label: string; level: number; disabled: boolean }[] {
  const tree = buildCategoryTree(categories);
  const result: { value: string; label: string; level: number; disabled: boolean }[] = [];

  const traverse = (nodes: RdoCategoryWithChildren[], depth: number) => {
    nodes.forEach(node => {
      const isAllowed = !filterByItemType || 
        node.allowed_item_types.includes(filterByItemType) ||
        node.allowed_item_types.length === 0;
      
      const prefix = '  '.repeat(depth);
      result.push({
        value: node.code,
        label: `${prefix}${node.name}`,
        level: node.level,
        disabled: node.level < 3 || !isAllowed, // Solo permitir nivel 3 (subcategorías)
      });
      traverse(node.children, depth + 1);
    });
  };

  traverse(tree, 0);
  return result;
}
