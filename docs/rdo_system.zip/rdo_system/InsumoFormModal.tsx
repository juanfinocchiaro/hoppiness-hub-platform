import { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Switch } from '@/components/ui/switch';
import { FormLayout, FormRow, FormSection } from '@/components/ui/forms-pro';
import { StickyActions } from '@/components/ui/forms-pro';
import { Package, Shield, AlertTriangle, Beef, Box, BarChart3 } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { LoadingButton } from '@/components/ui/loading-button';
import { useInsumoMutations, useCategoriasInsumo } from '@/hooks/useInsumos';
import { useProveedores } from '@/hooks/useProveedores';
import { RdoCategorySelector } from './RdoCategorySelector';
import { useRdoCategoryByCode } from '@/hooks/useRdoCategories';
import { UNIDAD_OPTIONS } from '@/types/financial';
import { ITEM_TYPE_OPTIONS, getItemTypeIcon } from '@/types/rdo';
import type { Insumo, InsumoFormData } from '@/types/financial';
import type { ItemType } from '@/types/rdo';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  insumo?: Insumo | null;
}

interface ExtendedFormData extends InsumoFormData {
  tipo_item: 'ingrediente' | 'insumo';
  rdo_category_code: string;
  tracks_stock: boolean;
  nivel_control: 'obligatorio' | 'semi_libre' | 'libre';
  proveedor_obligatorio_id?: string;
  precio_maximo_sugerido?: number;
  motivo_control?: string;
}

const EMPTY: ExtendedFormData = {
  nombre: '',
  unidad_base: 'kg',
  tipo_item: 'ingrediente',
  rdo_category_code: '',
  tracks_stock: true,
  nivel_control: 'libre',
};

const NIVEL_LABELS = {
  obligatorio: { label: '🔒 Obligatorio', desc: 'Proveedor fijo definido por la marca' },
  semi_libre: { label: '🟡 Semi-libre', desc: 'Especificación fija, proveedor flexible' },
  libre: { label: '🟢 Libre', desc: 'Sin restricciones, cualquier marca/proveedor' },
};

const TIPO_ITEM_INFO = {
  ingrediente: {
    icon: Beef,
    label: 'Ingrediente',
    description: 'Lo que se come el cliente: carne, pan, quesos, bebidas, salsas de cocina',
    color: 'text-orange-600 bg-orange-100',
    defaultTrackStock: true,
  },
  insumo: {
    icon: Box,
    label: 'Insumo',
    description: 'Descartables, limpieza, sobrecitos para clientes, material de empaque',
    color: 'text-blue-600 bg-blue-100',
    defaultTrackStock: false,
  },
};

export function InsumoFormModal({ open, onOpenChange, insumo }: Props) {
  const { create, update } = useInsumoMutations();
  const { data: categorias } = useCategoriasInsumo();
  const { data: proveedores } = useProveedores();
  const isEdit = !!insumo;

  const [form, setForm] = useState<ExtendedFormData>(EMPTY);
  
  // Obtener info de categoría seleccionada
  const selectedCategory = useRdoCategoryByCode(form.rdo_category_code);

  useEffect(() => {
    if (insumo) {
      setForm({
        nombre: insumo.nombre,
        categoria_id: insumo.categoria_id || undefined,
        unidad_base: insumo.unidad_base,
        categoria_pl: insumo.categoria_pl || undefined,
        precio_referencia: insumo.precio_referencia || undefined,
        proveedor_sugerido_id: insumo.proveedor_sugerido_id || undefined,
        descripcion: insumo.descripcion || undefined,
        tipo_item: (insumo as any).tipo_item || 'ingrediente',
        rdo_category_code: (insumo as any).rdo_category_code || '',
        tracks_stock: (insumo as any).tracks_stock ?? true,
        nivel_control: (insumo as any).nivel_control || 'libre',
        proveedor_obligatorio_id: (insumo as any).proveedor_obligatorio_id || undefined,
        precio_maximo_sugerido: (insumo as any).precio_maximo_sugerido || undefined,
        motivo_control: (insumo as any).motivo_control || undefined,
      });
    } else {
      setForm(EMPTY);
    }
  }, [insumo, open]);

  const set = (key: keyof ExtendedFormData, value: any) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  // Cuando cambia el tipo, actualizar tracks_stock por defecto
  const handleTipoChange = (tipo: 'ingrediente' | 'insumo') => {
    set('tipo_item', tipo);
    set('tracks_stock', TIPO_ITEM_INFO[tipo].defaultTrackStock);
    // Limpiar categoría RDO si no es compatible
    if (form.rdo_category_code) {
      set('rdo_category_code', '');
    }
  };

  const handleSubmit = async () => {
    if (!form.nombre.trim() || !form.rdo_category_code) return;

    const payload: any = {
      nombre: form.nombre,
      categoria_id: form.categoria_id || null,
      unidad_base: form.unidad_base,
      tipo_item: form.tipo_item,
      rdo_category_code: form.rdo_category_code,
      tracks_stock: form.tracks_stock,
      categoria_pl: selectedCategory?.name || form.categoria_pl || null, // Derivar de RDO
      precio_referencia: form.precio_referencia || null,
      descripcion: form.descripcion || null,
      nivel_control: form.nivel_control,
      motivo_control: form.motivo_control || null,
      precio_maximo_sugerido: form.precio_maximo_sugerido || null,
      proveedor_obligatorio_id: form.nivel_control === 'obligatorio' ? (form.proveedor_obligatorio_id || null) : null,
      proveedor_sugerido_id: form.nivel_control === 'semi_libre' ? (form.proveedor_sugerido_id || null) :
                              form.nivel_control === 'obligatorio' ? null :
                              (form.proveedor_sugerido_id || null),
    };

    if (isEdit) {
      await update.mutateAsync({ id: insumo!.id, data: payload });
    } else {
      await create.mutateAsync(payload);
    }
    onOpenChange(false);
  };

  const isPending = create.isPending || update.isPending;
  const tipoInfo = TIPO_ITEM_INFO[form.tipo_item];
  const TipoIcon = tipoInfo.icon;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            {isEdit ? 'Editar Insumo/Ingrediente' : 'Nuevo Insumo/Ingrediente'}
          </DialogTitle>
          <DialogDescription>
            Define si es un ingrediente (lo que come el cliente) o un insumo (descartables, limpieza)
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* TIPO DE ITEM - Lo más importante primero */}
          <FormSection title="¿Qué tipo de item es?" icon={Package}>
            <div className="grid grid-cols-2 gap-3">
              {(['ingrediente', 'insumo'] as const).map((tipo) => {
                const info = TIPO_ITEM_INFO[tipo];
                const Icon = info.icon;
                const isSelected = form.tipo_item === tipo;
                
                return (
                  <button
                    key={tipo}
                    type="button"
                    onClick={() => handleTipoChange(tipo)}
                    className={`p-4 rounded-lg border-2 text-left transition-all ${
                      isSelected 
                        ? 'border-primary bg-primary/5' 
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`p-2 rounded-lg ${info.color}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <span className="font-semibold">{info.label}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{info.description}</p>
                  </button>
                );
              })}
            </div>
          </FormSection>

          {/* CATEGORÍA RDO */}
          <FormSection title="Categoría del RDO" icon={BarChart3}>
            <div className="space-y-2">
              <Label className="text-sm flex items-center gap-2">
                ¿En qué línea del RDO impacta este {form.tipo_item}? *
                {selectedCategory && (
                  <Badge variant={selectedCategory.behavior === 'variable' ? 'default' : 'secondary'} className="text-xs">
                    {selectedCategory.behavior === 'variable' ? 'Variable' : 'Fijo'}
                  </Badge>
                )}
              </Label>
              <RdoCategorySelector
                value={form.rdo_category_code}
                onChange={(v) => set('rdo_category_code', v)}
                itemType={form.tipo_item}
                placeholder={`Seleccionar categoría para ${form.tipo_item}...`}
              />
              {selectedCategory?.description && (
                <p className="text-xs text-muted-foreground">{selectedCategory.description}</p>
              )}
            </div>
          </FormSection>

          {/* DATOS BÁSICOS */}
          <FormSection title="Datos del Item" icon={TipoIcon}>
            <FormLayout columns={1}>
              <FormRow label="Nombre" required>
                <Input
                  value={form.nombre}
                  onChange={(e) => set('nombre', e.target.value)}
                  placeholder={`Nombre del ${form.tipo_item}`}
                />
              </FormRow>
              <FormLayout columns={2}>
                <FormRow label="Categoría interna">
                  <Select value={form.categoria_id || 'none'} onValueChange={(v) => set('categoria_id', v === 'none' ? undefined : v)}>
                    <SelectTrigger><SelectValue placeholder="Sin categoría" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Sin categoría</SelectItem>
                      {categorias?.map((c) => (
                        <SelectItem key={c.id} value={c.id}>{c.nombre}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormRow>
                <FormRow label="Unidad base" required>
                  <Select value={form.unidad_base} onValueChange={(v) => set('unidad_base', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {UNIDAD_OPTIONS.map((u) => (
                        <SelectItem key={u.value} value={u.value}>{u.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormRow>
              </FormLayout>
              
              {/* Control de Stock */}
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div>
                  <Label className="font-medium">Controlar Stock</Label>
                  <p className="text-xs text-muted-foreground">
                    {form.tipo_item === 'ingrediente' 
                      ? 'Recomendado: permite calcular CMV y mermas'
                      : 'Opcional: útil para descartables con alto volumen'}
                  </p>
                </div>
                <Switch
                  checked={form.tracks_stock}
                  onCheckedChange={(v) => set('tracks_stock', v)}
                />
              </div>
            </FormLayout>
          </FormSection>

          {/* NIVEL DE CONTROL */}
          <FormSection title="Nivel de Control" icon={Shield}>
            <RadioGroup
              value={form.nivel_control}
              onValueChange={(v) => set('nivel_control', v)}
              className="space-y-2"
            >
              {(Object.entries(NIVEL_LABELS) as [string, { label: string; desc: string }][]).map(([value, { label, desc }]) => (
                <div key={value} className={`flex items-start gap-3 p-3 rounded-lg border ${form.nivel_control === value ? 'border-primary bg-primary/5' : 'border-border'}`}>
                  <RadioGroupItem value={value} id={`nivel-${value}`} className="mt-0.5" />
                  <div>
                    <Label htmlFor={`nivel-${value}`} className="font-medium cursor-pointer">{label}</Label>
                    <p className="text-xs text-muted-foreground">{desc}</p>
                  </div>
                </div>
              ))}
            </RadioGroup>

            {form.nivel_control === 'obligatorio' && (
              <div className="mt-3 space-y-3 p-3 bg-destructive/5 border border-destructive/20 rounded-lg">
                <FormRow label="Proveedor Obligatorio" required>
                  <Select value={form.proveedor_obligatorio_id || ''} onValueChange={(v) => set('proveedor_obligatorio_id', v)}>
                    <SelectTrigger><SelectValue placeholder="Seleccionar proveedor fijo..." /></SelectTrigger>
                    <SelectContent>
                      {proveedores?.map((p) => (
                        <SelectItem key={p.id} value={p.id}>{p.razon_social}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormRow>
              </div>
            )}

            {form.nivel_control === 'semi_libre' && (
              <div className="mt-3 space-y-3 p-3 bg-yellow-500/5 border border-yellow-500/20 rounded-lg">
                <FormRow label="Proveedor Sugerido">
                  <Select value={form.proveedor_sugerido_id || 'none'} onValueChange={(v) => set('proveedor_sugerido_id', v === 'none' ? undefined : v)}>
                    <SelectTrigger><SelectValue placeholder="Ninguno" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Ninguno</SelectItem>
                      {proveedores?.map((p) => (
                        <SelectItem key={p.id} value={p.id}>{p.razon_social}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormRow>
              </div>
            )}

            <FormRow label="Motivo del control" className="mt-3">
              <Input value={form.motivo_control || ''} onChange={(e) => set('motivo_control', e.target.value)} placeholder="Por qué se controla este item" />
            </FormRow>
          </FormSection>

          {/* PRECIOS */}
          <FormSection title="Precios de Referencia">
            <FormLayout columns={2}>
              <FormRow label="Precio referencia ($)">
                <Input
                  type="number"
                  step="0.01"
                  value={form.precio_referencia ?? ''}
                  onChange={(e) => set('precio_referencia', e.target.value ? Number(e.target.value) : undefined)}
                />
              </FormRow>
              <FormRow label="Precio máximo sugerido ($)">
                <Input
                  type="number"
                  step="0.01"
                  value={form.precio_maximo_sugerido ?? ''}
                  onChange={(e) => set('precio_maximo_sugerido', e.target.value ? Number(e.target.value) : undefined)}
                />
              </FormRow>
            </FormLayout>
          </FormSection>

          <FormRow label="Descripción / Especificaciones">
            <Textarea
              value={form.descripcion || ''}
              onChange={(e) => set('descripcion', e.target.value)}
              rows={2}
              placeholder="Detalles adicionales, marca específica, etc."
            />
          </FormRow>

          <StickyActions>
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <LoadingButton 
              loading={isPending} 
              onClick={handleSubmit}
              disabled={!form.nombre.trim() || !form.rdo_category_code}
            >
              {isEdit ? 'Guardar' : `Crear ${form.tipo_item === 'ingrediente' ? 'Ingrediente' : 'Insumo'}`}
            </LoadingButton>
          </StickyActions>
        </div>
      </DialogContent>
    </Dialog>
  );
}
