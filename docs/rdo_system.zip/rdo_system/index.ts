// Componentes de Finanzas - Exports centralizados

// RDO System
export { RdoCategorySelector, RdoCategorySelectSimple, RdoCategoryBadge } from './RdoCategorySelector';
export { RdoDashboard } from './RdoDashboard';

// Forms
export { GastoFormModal } from './GastoFormModal';
export { InsumoFormModal } from './InsumoFormModal';

// Re-export types
export type {
  RdoCategory,
  RdoCategoryWithChildren,
  RdoReportLine,
  RdoReport,
  RdoSection,
  CostBehavior,
  ItemType,
  InsumoExtended,
  InsumoFormData,
  ProveedorExtended,
  ProveedorFormData,
  GastoExtended,
  GastoFormDataExtended,
} from '@/types/rdo';

export {
  ITEM_TYPE_OPTIONS,
  RDO_SECTION_LABELS,
  BEHAVIOR_LABELS,
  getItemTypeIcon,
  getRdoSectionColor,
  buildCategoryTree,
  flattenCategoriesForSelect,
} from '@/types/rdo';
