import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { toast } from 'sonner';
import type { 
  RdoCategory, 
  RdoCategoryWithChildren, 
  RdoReportLine,
  RdoSection,
  ItemType,
  buildCategoryTree,
  flattenCategoriesForSelect 
} from '@/types/rdo';

// =====================================================
// HOOK PARA CATEGORÍAS RDO
// =====================================================

export function useRdoCategories(options?: {
  section?: RdoSection;
  itemType?: ItemType;
  onlyActive?: boolean;
  onlySelectable?: boolean; // Solo nivel 3
}) {
  const { user } = useAuth();
  const { section, itemType, onlyActive = true, onlySelectable = false } = options || {};

  return useQuery({
    queryKey: ['rdo-categories', section, itemType, onlyActive, onlySelectable],
    queryFn: async () => {
      let query = supabase
        .from('rdo_categories')
        .select('*')
        .order('sort_order', { ascending: true });

      if (onlyActive) {
        query = query.eq('is_active', true);
      }

      if (section) {
        query = query.eq('rdo_section', section);
      }

      if (onlySelectable) {
        query = query.eq('level', 3);
      }

      if (itemType) {
        query = query.contains('allowed_item_types', [itemType]);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as RdoCategory[];
    },
    enabled: !!user,
    staleTime: 5 * 60 * 1000, // Cache por 5 minutos
  });
}

// Hook para obtener categorías como árbol jerárquico
export function useRdoCategoriesTree(section?: RdoSection) {
  const { data: categories, ...rest } = useRdoCategories({ section });

  const tree = categories ? buildCategoryTreeInternal(categories) : [];

  return {
    ...rest,
    data: tree,
    flatCategories: categories,
  };
}

// Hook para obtener opciones de select
export function useRdoCategoryOptions(itemType?: ItemType) {
  const { data: categories, ...rest } = useRdoCategories({ itemType });

  const options = categories 
    ? flattenCategoriesForSelectInternal(categories, itemType)
    : [];

  return {
    ...rest,
    data: options,
  };
}

// =====================================================
// HOOK PARA REPORTE RDO
// =====================================================

export function useRdoReport(branchId: string, periodo: string) {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['rdo-report', branchId, periodo],
    queryFn: async () => {
      const { data, error } = await supabase
        .rpc('get_rdo_report', {
          p_branch_id: branchId,
          p_periodo: periodo,
        });

      if (error) throw error;
      return data as RdoReportLine[];
    },
    enabled: !!user && !!branchId && !!periodo,
  });
}

// Hook para obtener datos del RDO desde la vista
export function useRdoReportData(branchId: string, periodo: string) {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['rdo-report-data', branchId, periodo],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('rdo_report_data')
        .select('*')
        .eq('branch_id', branchId)
        .eq('periodo', periodo)
        .order('sort_order', { ascending: true });

      if (error) throw error;
      return data;
    },
    enabled: !!user && !!branchId && !!periodo,
  });
}

// =====================================================
// MUTACIONES (solo superadmin)
// =====================================================

export function useRdoCategoryMutations() {
  const qc = useQueryClient();
  const { user } = useAuth();

  const create = useMutation({
    mutationFn: async (data: Partial<RdoCategory>) => {
      const { data: result, error } = await supabase
        .from('rdo_categories')
        .insert(data)
        .select()
        .single();
      if (error) throw error;
      return result;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['rdo-categories'] });
      toast.success('Categoría creada');
    },
    onError: (e: Error) => toast.error(`Error: ${e.message}`),
  });

  const update = useMutation({
    mutationFn: async ({ code, data }: { code: string; data: Partial<RdoCategory> }) => {
      const { error } = await supabase
        .from('rdo_categories')
        .update(data)
        .eq('code', code);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['rdo-categories'] });
      toast.success('Categoría actualizada');
    },
    onError: (e: Error) => toast.error(`Error: ${e.message}`),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ code, is_active }: { code: string; is_active: boolean }) => {
      const { error } = await supabase
        .from('rdo_categories')
        .update({ is_active })
        .eq('code', code);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['rdo-categories'] });
      toast.success('Estado actualizado');
    },
    onError: (e: Error) => toast.error(`Error: ${e.message}`),
  });

  return { create, update, toggleActive };
}

// =====================================================
// FUNCIONES HELPER INTERNAS
// =====================================================

interface RdoCategoryWithChildrenInternal extends RdoCategory {
  children: RdoCategoryWithChildrenInternal[];
}

function buildCategoryTreeInternal(categories: RdoCategory[]): RdoCategoryWithChildrenInternal[] {
  const map = new Map<string, RdoCategoryWithChildrenInternal>();
  const roots: RdoCategoryWithChildrenInternal[] = [];

  // Crear mapa con children vacíos
  categories.forEach(cat => {
    map.set(cat.code, { ...cat, children: [] });
  });

  // Construir árbol
  categories.forEach(cat => {
    const node = map.get(cat.code)!;
    if (cat.parent_code && map.has(cat.parent_code)) {
      map.get(cat.parent_code)!.children.push(node);
    } else if (!cat.parent_code || cat.level === 1) {
      roots.push(node);
    }
  });

  // Ordenar hijos por sort_order
  const sortChildren = (nodes: RdoCategoryWithChildrenInternal[]) => {
    nodes.sort((a, b) => a.sort_order - b.sort_order);
    nodes.forEach(n => sortChildren(n.children));
  };
  sortChildren(roots);

  return roots;
}

function flattenCategoriesForSelectInternal(
  categories: RdoCategory[],
  filterByItemType?: ItemType
): { value: string; label: string; level: number; disabled: boolean; section: RdoSection }[] {
  const tree = buildCategoryTreeInternal(categories);
  const result: { value: string; label: string; level: number; disabled: boolean; section: RdoSection }[] = [];

  const traverse = (nodes: RdoCategoryWithChildrenInternal[], depth: number) => {
    nodes.forEach(node => {
      const isAllowed = !filterByItemType || 
        node.allowed_item_types.includes(filterByItemType) ||
        node.allowed_item_types.length === 0;
      
      const prefix = depth > 0 ? '│  '.repeat(depth - 1) + '├─ ' : '';
      result.push({
        value: node.code,
        label: `${prefix}${node.name}`,
        level: node.level,
        disabled: node.level < 3 || !isAllowed,
        section: node.rdo_section,
      });
      traverse(node.children, depth + 1);
    });
  };

  traverse(tree, 0);
  return result;
}

// =====================================================
// HOOK PARA CATEGORÍAS AGRUPADAS POR SECCIÓN
// =====================================================

export function useRdoCategoriesBySection() {
  const { data: categories, ...rest } = useRdoCategories();

  const grouped = categories?.reduce((acc, cat) => {
    if (!acc[cat.rdo_section]) {
      acc[cat.rdo_section] = [];
    }
    acc[cat.rdo_section].push(cat);
    return acc;
  }, {} as Record<RdoSection, RdoCategory[]>);

  return {
    ...rest,
    data: grouped,
  };
}

// =====================================================
// HOOK PARA BUSCAR CATEGORÍA POR CÓDIGO
// =====================================================

export function useRdoCategoryByCode(code: string | null | undefined) {
  const { data: categories } = useRdoCategories();
  
  if (!code || !categories) return null;
  return categories.find(c => c.code === code) || null;
}
