import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { 
  ChevronDown, 
  ChevronRight, 
  TrendingUp, 
  TrendingDown,
  DollarSign,
  FileSpreadsheet,
  Download,
  RefreshCw
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useRdoReport, useRdoCategories } from '@/hooks/useRdoCategories';
import { useVentasMensuales } from '@/hooks/useVentasMensuales';
import type { RdoReportLine, RdoSection } from '@/types/rdo';

interface RdoDashboardProps {
  branchId: string;
  branchName?: string;
}

export function RdoDashboard({ branchId, branchName }: RdoDashboardProps) {
  const [periodo, setPeriodo] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['costos_variables', 'costos_fijos']));

  const { data: reportLines, isLoading, refetch } = useRdoReport(branchId, periodo);
  const { data: ventas } = useVentasMensuales(branchId, periodo);
  const { data: allCategories } = useRdoCategories();

  // Calcular total de ingresos del período
  const totalIngresos = useMemo(() => {
    if (!ventas || ventas.length === 0) return 0;
    return ventas.reduce((sum, v) => {
      // Usar fc_total + ft_total si existen, o total_facturado como fallback
      const fcTotal = Number((v as any).fc_total) || 0;
      const ftTotal = Number((v as any).ft_total) || 0;
      const totalFact = Number((v as any).total_facturado) || 0;
      return sum + (fcTotal + ftTotal || totalFact);
    }, 0);
  }, [ventas]);

  // Procesar líneas del reporte en estructura jerárquica
  const processedReport = useMemo(() => {
    if (!reportLines || !allCategories) return null;

    const linesMap = new Map(reportLines.map(l => [l.category_code, l]));
    
    // Crear estructura con todas las categorías y sus valores
    const sections: Record<RdoSection, {
      total: number;
      percentage: number;
      categories: (RdoReportLine & { children: RdoReportLine[] })[];
    }> = {
      ingresos: { total: totalIngresos, percentage: 100, categories: [] },
      costos_variables: { total: 0, percentage: 0, categories: [] },
      costos_fijos: { total: 0, percentage: 0, categories: [] },
      financiacion: { total: 0, percentage: 0, categories: [] },
      impuestos: { total: 0, percentage: 0, categories: [] },
    };

    // Agrupar categorías nivel 2 con sus hijos nivel 3
    const level2Cats = allCategories.filter(c => c.level === 2);
    
    level2Cats.forEach(cat => {
      const line = linesMap.get(cat.code);
      const children = allCategories
        .filter(c => c.parent_code === cat.code && c.level === 3)
        .map(child => {
          const childLine = linesMap.get(child.code);
          return {
            category_code: child.code,
            category_name: child.name,
            parent_code: child.parent_code,
            level: child.level,
            rdo_section: child.rdo_section as RdoSection,
            behavior: child.behavior as 'variable' | 'fijo',
            sort_order: child.sort_order,
            total: childLine?.total || 0,
            percentage: totalIngresos > 0 ? ((childLine?.total || 0) / totalIngresos * 100) : 0,
          };
        })
        .filter(c => c.total > 0); // Solo mostrar los que tienen valores

      const categoryTotal = children.reduce((sum, c) => sum + c.total, 0);
      
      if (categoryTotal > 0 || line?.total) {
        const section = cat.rdo_section as RdoSection;
        sections[section].categories.push({
          category_code: cat.code,
          category_name: cat.name,
          parent_code: cat.parent_code,
          level: cat.level,
          rdo_section: section,
          behavior: cat.behavior as 'variable' | 'fijo',
          sort_order: cat.sort_order,
          total: categoryTotal || line?.total || 0,
          percentage: totalIngresos > 0 ? ((categoryTotal || line?.total || 0) / totalIngresos * 100) : 0,
          children,
        });
        sections[section].total += categoryTotal || line?.total || 0;
      }
    });

    // Calcular porcentajes de secciones
    Object.values(sections).forEach(s => {
      s.percentage = totalIngresos > 0 ? (s.total / totalIngresos * 100) : 0;
    });

    // Ordenar categorías
    Object.values(sections).forEach(s => {
      s.categories.sort((a, b) => a.sort_order - b.sort_order);
    });

    return sections;
  }, [reportLines, allCategories, totalIngresos]);

  // Calcular resultados
  const results = useMemo(() => {
    if (!processedReport) return null;

    const margenBruto = totalIngresos - processedReport.costos_variables.total;
    const ebit = margenBruto - processedReport.costos_fijos.total;
    const resultadoNeto = ebit - processedReport.financiacion.total - processedReport.impuestos.total;

    return {
      ingresos: totalIngresos,
      costosVariables: processedReport.costos_variables.total,
      margenBruto,
      margenBrutoPct: totalIngresos > 0 ? (margenBruto / totalIngresos * 100) : 0,
      costosFijos: processedReport.costos_fijos.total,
      ebit,
      ebitPct: totalIngresos > 0 ? (ebit / totalIngresos * 100) : 0,
      financiacion: processedReport.financiacion.total,
      impuestos: processedReport.impuestos.total,
      resultadoNeto,
      resultadoNetoPct: totalIngresos > 0 ? (resultadoNeto / totalIngresos * 100) : 0,
    };
  }, [processedReport, totalIngresos]);

  const toggleSection = (section: string) => {
    setExpandedSections(prev => {
      const next = new Set(prev);
      if (next.has(section)) {
        next.delete(section);
      } else {
        next.add(section);
      }
      return next;
    });
  };

  // Generar opciones de período (últimos 12 meses)
  const periodoOptions = useMemo(() => {
    const options = [];
    const now = new Date();
    for (let i = 0; i < 12; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const label = d.toLocaleDateString('es-AR', { month: 'long', year: 'numeric' });
      options.push({ value, label: label.charAt(0).toUpperCase() + label.slice(1) });
    }
    return options;
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-AR', { 
      style: 'currency', 
      currency: 'ARS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatPct = (pct: number) => `${pct.toFixed(2)}%`;

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-32" />
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3, 4, 5].map(i => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header con controles */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <FileSpreadsheet className="h-6 w-6 text-primary" />
            RDO - Resultado de Operaciones
          </h2>
          {branchName && <p className="text-muted-foreground">{branchName}</p>}
        </div>
        <div className="flex items-center gap-2">
          <Select value={periodo} onValueChange={setPeriodo}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {periodoOptions.map(opt => (
                <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Cards de resumen */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <SummaryCard
          title="Ingresos"
          value={formatCurrency(results?.ingresos || 0)}
          percentage="100%"
          variant="neutral"
        />
        <SummaryCard
          title="Margen Bruto"
          value={formatCurrency(results?.margenBruto || 0)}
          percentage={formatPct(results?.margenBrutoPct || 0)}
          variant={(results?.margenBrutoPct || 0) > 40 ? 'positive' : 'warning'}
        />
        <SummaryCard
          title="EBIT"
          value={formatCurrency(results?.ebit || 0)}
          percentage={formatPct(results?.ebitPct || 0)}
          variant={(results?.ebitPct || 0) > 15 ? 'positive' : (results?.ebitPct || 0) > 0 ? 'warning' : 'negative'}
        />
        <SummaryCard
          title="Resultado Neto"
          value={formatCurrency(results?.resultadoNeto || 0)}
          percentage={formatPct(results?.resultadoNetoPct || 0)}
          variant={(results?.resultadoNetoPct || 0) > 10 ? 'positive' : (results?.resultadoNetoPct || 0) > 0 ? 'warning' : 'negative'}
        />
      </div>

      {/* Tabla del RDO */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-semibold">Concepto</th>
                  <th className="text-right p-3 font-semibold w-32">Monto</th>
                  <th className="text-right p-3 font-semibold w-20">%</th>
                </tr>
              </thead>
              <tbody>
                {/* INGRESOS */}
                <RdoSectionRow
                  title="INGRESOS"
                  total={formatCurrency(results?.ingresos || 0)}
                  percentage="100.00%"
                  variant="income"
                  isExpanded={false}
                />

                {/* COSTOS VARIABLES */}
                <RdoSectionRow
                  title="COSTOS VARIABLES"
                  total={formatCurrency(processedReport?.costos_variables.total || 0)}
                  percentage={formatPct(processedReport?.costos_variables.percentage || 0)}
                  variant="variable"
                  isExpanded={expandedSections.has('costos_variables')}
                  onToggle={() => toggleSection('costos_variables')}
                  expandable
                />
                {expandedSections.has('costos_variables') && processedReport?.costos_variables.categories.map(cat => (
                  <RdoCategoryRows 
                    key={cat.category_code} 
                    category={cat} 
                    formatCurrency={formatCurrency}
                    formatPct={formatPct}
                  />
                ))}

                {/* MARGEN BRUTO */}
                <RdoResultRow
                  title="MARGEN BRUTO"
                  total={formatCurrency(results?.margenBruto || 0)}
                  percentage={formatPct(results?.margenBrutoPct || 0)}
                  variant={(results?.margenBrutoPct || 0) > 40 ? 'positive' : 'warning'}
                />

                {/* COSTOS FIJOS */}
                <RdoSectionRow
                  title="COSTOS FIJOS"
                  total={formatCurrency(processedReport?.costos_fijos.total || 0)}
                  percentage={formatPct(processedReport?.costos_fijos.percentage || 0)}
                  variant="fixed"
                  isExpanded={expandedSections.has('costos_fijos')}
                  onToggle={() => toggleSection('costos_fijos')}
                  expandable
                />
                {expandedSections.has('costos_fijos') && processedReport?.costos_fijos.categories.map(cat => (
                  <RdoCategoryRows 
                    key={cat.category_code} 
                    category={cat} 
                    formatCurrency={formatCurrency}
                    formatPct={formatPct}
                  />
                ))}

                {/* RESULTADO OPERATIVO (EBIT) */}
                <RdoResultRow
                  title="RESULTADO OPERATIVO (EBIT)"
                  total={formatCurrency(results?.ebit || 0)}
                  percentage={formatPct(results?.ebitPct || 0)}
                  variant={(results?.ebitPct || 0) > 15 ? 'positive' : 'warning'}
                  highlight
                />

                {/* FINANCIACIÓN */}
                {(processedReport?.financiacion.total || 0) > 0 && (
                  <>
                    <RdoSectionRow
                      title="FINANCIACIÓN"
                      total={formatCurrency(processedReport?.financiacion.total || 0)}
                      percentage={formatPct(processedReport?.financiacion.percentage || 0)}
                      variant="fixed"
                      isExpanded={expandedSections.has('financiacion')}
                      onToggle={() => toggleSection('financiacion')}
                      expandable
                    />
                    {expandedSections.has('financiacion') && processedReport?.financiacion.categories.map(cat => (
                      <RdoCategoryRows 
                        key={cat.category_code} 
                        category={cat} 
                        formatCurrency={formatCurrency}
                        formatPct={formatPct}
                      />
                    ))}
                  </>
                )}

                {/* IMPUESTOS */}
                {(processedReport?.impuestos.total || 0) > 0 && (
                  <>
                    <RdoSectionRow
                      title="IMPUESTOS"
                      total={formatCurrency(processedReport?.impuestos.total || 0)}
                      percentage={formatPct(processedReport?.impuestos.percentage || 0)}
                      variant="fixed"
                      isExpanded={expandedSections.has('impuestos')}
                      onToggle={() => toggleSection('impuestos')}
                      expandable
                    />
                    {expandedSections.has('impuestos') && processedReport?.impuestos.categories.map(cat => (
                      <RdoCategoryRows 
                        key={cat.category_code} 
                        category={cat} 
                        formatCurrency={formatCurrency}
                        formatPct={formatPct}
                      />
                    ))}
                  </>
                )}

                {/* RESULTADO NETO */}
                <RdoResultRow
                  title="RESULTADO NETO"
                  total={formatCurrency(results?.resultadoNeto || 0)}
                  percentage={formatPct(results?.resultadoNetoPct || 0)}
                  variant={(results?.resultadoNetoPct || 0) > 10 ? 'positive' : (results?.resultadoNetoPct || 0) > 0 ? 'warning' : 'negative'}
                  highlight
                  final
                />
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Componentes auxiliares

interface SummaryCardProps {
  title: string;
  value: string;
  percentage: string;
  variant: 'positive' | 'negative' | 'warning' | 'neutral';
}

function SummaryCard({ title, value, percentage, variant }: SummaryCardProps) {
  const colors = {
    positive: 'text-green-600',
    negative: 'text-red-600',
    warning: 'text-yellow-600',
    neutral: 'text-foreground',
  };

  return (
    <Card>
      <CardContent className="p-4">
        <p className="text-sm text-muted-foreground">{title}</p>
        <p className={cn('text-xl font-bold', colors[variant])}>{value}</p>
        <p className="text-sm text-muted-foreground">{percentage}</p>
      </CardContent>
    </Card>
  );
}

interface RdoSectionRowProps {
  title: string;
  total: string;
  percentage: string;
  variant: 'income' | 'variable' | 'fixed';
  isExpanded?: boolean;
  onToggle?: () => void;
  expandable?: boolean;
}

function RdoSectionRow({ title, total, percentage, variant, isExpanded, onToggle, expandable }: RdoSectionRowProps) {
  const bgColors = {
    income: 'bg-green-100',
    variable: 'bg-orange-100',
    fixed: 'bg-blue-100',
  };

  return (
    <tr className={cn('font-bold', bgColors[variant])}>
      <td className="p-3">
        <button 
          onClick={onToggle} 
          className={cn('flex items-center gap-2', expandable && 'cursor-pointer hover:opacity-70')}
          disabled={!expandable}
        >
          {expandable && (
            isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
          )}
          {title}
        </button>
      </td>
      <td className="text-right p-3">{total}</td>
      <td className="text-right p-3">{percentage}</td>
    </tr>
  );
}

interface RdoResultRowProps {
  title: string;
  total: string;
  percentage: string;
  variant: 'positive' | 'warning' | 'negative';
  highlight?: boolean;
  final?: boolean;
}

function RdoResultRow({ title, total, percentage, variant, highlight, final }: RdoResultRowProps) {
  const textColors = {
    positive: 'text-green-700',
    warning: 'text-yellow-700',
    negative: 'text-red-700',
  };

  const bgColors = {
    positive: highlight ? 'bg-green-200' : 'bg-green-50',
    warning: highlight ? 'bg-yellow-200' : 'bg-yellow-50',
    negative: highlight ? 'bg-red-200' : 'bg-red-50',
  };

  return (
    <tr className={cn('font-bold', bgColors[variant], final && 'border-t-2 border-black')}>
      <td className={cn('p-3', textColors[variant])}>{title}</td>
      <td className={cn('text-right p-3', textColors[variant])}>{total}</td>
      <td className={cn('text-right p-3', textColors[variant])}>{percentage}</td>
    </tr>
  );
}

interface RdoCategoryRowsProps {
  category: RdoReportLine & { children: RdoReportLine[] };
  formatCurrency: (n: number) => string;
  formatPct: (n: number) => string;
}

function RdoCategoryRows({ category, formatCurrency, formatPct }: RdoCategoryRowsProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <>
      <tr className="bg-muted/30 hover:bg-muted/50">
        <td className="p-3 pl-8">
          <button 
            onClick={() => setExpanded(!expanded)}
            className={cn('flex items-center gap-2 font-medium', category.children.length > 0 && 'cursor-pointer')}
          >
            {category.children.length > 0 && (
              expanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />
            )}
            {category.category_name}
          </button>
        </td>
        <td className="text-right p-3 font-medium">{formatCurrency(category.total)}</td>
        <td className="text-right p-3 text-muted-foreground">{formatPct(category.percentage)}</td>
      </tr>
      {expanded && category.children.map(child => (
        <tr key={child.category_code} className="hover:bg-muted/30">
          <td className="p-2 pl-14 text-sm text-muted-foreground">{child.category_name}</td>
          <td className="text-right p-2 text-sm">{formatCurrency(child.total)}</td>
          <td className="text-right p-2 text-sm text-muted-foreground">{formatPct(child.percentage)}</td>
        </tr>
      ))}
    </>
  );
}

export default RdoDashboard;
