import { useState, useMemo } from 'react';
import { Check, ChevronsUpDown, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { useRdoCategoryOptions, useRdoCategoryByCode } from '@/hooks/useRdoCategories';
import { getRdoSectionColor, RDO_SECTION_LABELS } from '@/types/rdo';
import type { ItemType, RdoSection } from '@/types/rdo';

interface RdoCategorySelectorProps {
  value: string | null | undefined;
  onChange: (value: string) => void;
  itemType?: ItemType;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  showSectionBadge?: boolean;
}

export function RdoCategorySelector({
  value,
  onChange,
  itemType,
  placeholder = 'Seleccionar categoría RDO...',
  disabled = false,
  className,
  showSectionBadge = true,
}: RdoCategorySelectorProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  
  const { data: options, isLoading } = useRdoCategoryOptions(itemType);
  const selectedCategory = useRdoCategoryByCode(value);

  // Filtrar opciones por búsqueda
  const filteredOptions = useMemo(() => {
    if (!options) return [];
    if (!search) return options;
    
    const searchLower = search.toLowerCase();
    return options.filter(opt => 
      opt.label.toLowerCase().includes(searchLower)
    );
  }, [options, search]);

  // Agrupar por sección
  const groupedOptions = useMemo(() => {
    const groups: Record<string, typeof filteredOptions> = {};
    
    filteredOptions.forEach(opt => {
      const section = opt.section;
      if (!groups[section]) {
        groups[section] = [];
      }
      groups[section].push(opt);
    });
    
    return groups;
  }, [filteredOptions]);

  const handleSelect = (code: string) => {
    onChange(code);
    setOpen(false);
    setSearch('');
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          disabled={disabled || isLoading}
          className={cn('w-full justify-between font-normal', className)}
        >
          <span className="truncate flex items-center gap-2">
            {selectedCategory ? (
              <>
                <span className="truncate">{selectedCategory.name}</span>
                {showSectionBadge && (
                  <Badge 
                    variant="secondary" 
                    className={cn('text-xs shrink-0', getRdoSectionColor(selectedCategory.rdo_section))}
                  >
                    {selectedCategory.behavior === 'variable' ? 'V' : 'F'}
                  </Badge>
                )}
              </>
            ) : (
              <span className="text-muted-foreground">{placeholder}</span>
            )}
          </span>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[400px] p-0" align="start">
        <Command shouldFilter={false}>
          <div className="flex items-center border-b px-3">
            <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
            <input
              placeholder="Buscar categoría..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex h-10 w-full bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>
          <CommandList className="max-h-[300px]">
            <CommandEmpty>No se encontraron categorías.</CommandEmpty>
            
            {Object.entries(groupedOptions).map(([section, sectionOptions]) => (
              <CommandGroup 
                key={section} 
                heading={
                  <span className={cn('px-2 py-1 rounded text-xs font-medium', getRdoSectionColor(section as RdoSection))}>
                    {RDO_SECTION_LABELS[section as RdoSection] || section}
                  </span>
                }
              >
                {sectionOptions.map((option) => (
                  <CommandItem
                    key={option.value}
                    value={option.value}
                    onSelect={() => !option.disabled && handleSelect(option.value)}
                    disabled={option.disabled}
                    className={cn(
                      'cursor-pointer',
                      option.disabled && 'opacity-50 cursor-not-allowed',
                      option.level === 1 && 'font-bold',
                      option.level === 2 && 'font-semibold pl-4',
                      option.level === 3 && 'pl-8',
                    )}
                  >
                    <Check
                      className={cn(
                        'mr-2 h-4 w-4',
                        value === option.value ? 'opacity-100' : 'opacity-0'
                      )}
                    />
                    <span className="truncate">{option.label}</span>
                    {option.level === 3 && (
                      <Badge 
                        variant="outline" 
                        className="ml-auto text-[10px] px-1"
                      >
                        Nivel 3
                      </Badge>
                    )}
                  </CommandItem>
                ))}
              </CommandGroup>
            ))}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

// =====================================================
// VERSIÓN SIMPLE (sin combobox, solo select)
// =====================================================

interface RdoCategorySelectSimpleProps {
  value: string | null | undefined;
  onChange: (value: string) => void;
  itemType?: ItemType;
  section?: RdoSection;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

export function RdoCategorySelectSimple({
  value,
  onChange,
  itemType,
  section,
  placeholder = 'Seleccionar...',
  disabled = false,
  className,
}: RdoCategorySelectSimpleProps) {
  const { data: options, isLoading } = useRdoCategoryOptions(itemType);

  // Filtrar por sección si se especifica
  const filteredOptions = useMemo(() => {
    if (!options) return [];
    if (!section) return options.filter(o => !o.disabled);
    return options.filter(o => o.section === section && !o.disabled);
  }, [options, section]);

  return (
    <select
      value={value || ''}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled || isLoading}
      className={cn(
        'flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm',
        'ring-offset-background focus-visible:outline-none focus-visible:ring-2',
        'focus-visible:ring-ring focus-visible:ring-offset-2',
        'disabled:cursor-not-allowed disabled:opacity-50',
        className
      )}
    >
      <option value="">{placeholder}</option>
      {filteredOptions.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}

// =====================================================
// DISPLAY DE CATEGORÍA (solo lectura)
// =====================================================

interface RdoCategoryBadgeProps {
  code: string | null | undefined;
  showSection?: boolean;
  className?: string;
}

export function RdoCategoryBadge({ code, showSection = true, className }: RdoCategoryBadgeProps) {
  const category = useRdoCategoryByCode(code);

  if (!category) {
    return <span className="text-muted-foreground text-sm">Sin categoría</span>;
  }

  return (
    <div className={cn('flex items-center gap-2', className)}>
      <span className="text-sm">{category.name}</span>
      {showSection && (
        <Badge 
          variant="secondary" 
          className={cn('text-xs', getRdoSectionColor(category.rdo_section))}
        >
          {category.behavior === 'variable' ? 'Variable' : 'Fijo'}
        </Badge>
      )}
    </div>
  );
}

export default RdoCategorySelector;
