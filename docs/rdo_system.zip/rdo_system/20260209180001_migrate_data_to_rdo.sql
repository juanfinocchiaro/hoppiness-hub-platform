-- =====================================================
-- MIGRACIÓN DE DATOS EXISTENTES A CATEGORÍAS RDO
-- =====================================================
-- Este script mapea los datos existentes (gastos, insumos) 
-- a las nuevas categorías RDO basándose en la categoría legacy

-- 1. MAPEAR GASTOS EXISTENTES
-- =====================================================
UPDATE gastos 
SET rdo_category_code = CASE categoria_principal
  -- Servicios básicos
  WHEN 'servicios' THEN 
    CASE 
      WHEN LOWER(concepto) LIKE '%luz%' OR LOWER(concepto) LIKE '%epec%' OR LOWER(concepto) LIKE '%electr%' THEN 'energia_electrica'
      WHEN LOWER(concepto) LIKE '%gas%' OR LOWER(concepto) LIKE '%ecogas%' THEN 'gas'
      WHEN LOWER(concepto) LIKE '%internet%' OR LOWER(concepto) LIKE '%airsat%' OR LOWER(concepto) LIKE '%telefon%' THEN 'internet_telefonia'
      WHEN LOWER(concepto) LIKE '%agua%' THEN 'agua'
      ELSE 'energia_electrica' -- Default para servicios
    END
  -- Alquileres
  WHEN 'alquileres' THEN 
    CASE 
      WHEN LOWER(concepto) LIKE '%expensa%' OR LOWER(concepto) LIKE '%comun%' THEN 'expensas'
      ELSE 'alquiler'
    END
  -- Sueldos y laborales
  WHEN 'sueldos' THEN 
    CASE 
      WHEN LOWER(concepto) LIKE '%carga%' OR LOWER(concepto) LIKE '%social%' OR LOWER(concepto) LIKE '%aporte%' THEN 'cargas_sociales'
      WHEN LOWER(concepto) LIKE '%comida%' OR LOWER(concepto) LIKE '%vianda%' OR LOWER(concepto) LIKE '%espeche%' THEN 'comida_personal'
      ELSE 'sueldos'
    END
  -- Impuestos
  WHEN 'impuestos' THEN 
    CASE 
      WHEN LOWER(concepto) LIKE '%iibb%' OR LOWER(concepto) LIKE '%bruto%' THEN 'iibb'
      WHEN LOWER(concepto) LIKE '%iva%' THEN 'iva_no_computable'
      WHEN LOWER(concepto) LIKE '%debito%' OR LOWER(concepto) LIKE '%credito%' OR LOWER(concepto) LIKE '%cheque%' THEN 'debitos_creditos'
      WHEN LOWER(concepto) LIKE '%comercio%' OR LOWER(concepto) LIKE '%industria%' OR LOWER(concepto) LIKE '%municipal%' THEN 'comercio_industria'
      ELSE 'iibb'
    END
  -- Mantenimiento
  WHEN 'mantenimiento' THEN 'mantenimiento_reparaciones'
  -- Marketing
  WHEN 'marketing' THEN 
    CASE 
      WHEN LOWER(concepto) LIKE '%fee%' OR LOWER(concepto) LIKE '%canon%' OR LOWER(concepto) LIKE '%franquicia%' THEN 'fee_marca'
      ELSE 'marketing'
    END
  -- Logística
  WHEN 'logistica' THEN 
    CASE 
      WHEN LOWER(concepto) LIKE '%rappi%' THEN 'cadetes_rappiboy'
      WHEN LOWER(concepto) LIKE '%cadete%' OR LOWER(concepto) LIKE '%delivery%' THEN 'cadetes_terceros'
      WHEN LOWER(concepto) LIKE '%flete%' THEN 'fletes_locales'
      ELSE 'abastecimiento'
    END
  -- Administrativos
  WHEN 'administrativos' THEN 
    CASE 
      WHEN LOWER(concepto) LIKE '%contab%' OR LOWER(concepto) LIKE '%estudio%' OR LOWER(concepto) LIKE '%carrizo%' THEN 'estudio_contable'
      WHEN LOWER(concepto) LIKE '%software%' OR LOWER(concepto) LIKE '%sistema%' OR LOWER(concepto) LIKE '%nucleo%' THEN 'software_gestion'
      WHEN LOWER(concepto) LIKE '%bromat%' THEN 'bromatologia'
      ELSE 'admin_interna'
    END
  -- Varios - intentar inferir
  WHEN 'varios' THEN 
    CASE 
      WHEN LOWER(concepto) LIKE '%limp%' OR LOWER(concepto) LIKE '%higien%' THEN 'limpieza_higiene'
      WHEN LOWER(concepto) LIKE '%uniforme%' THEN 'uniformes'
      WHEN LOWER(concepto) LIKE '%librer%' OR LOWER(concepto) LIKE '%papel%' THEN 'utiles_libreria'
      WHEN LOWER(concepto) LIKE '%seguro%' THEN 'seguro_local'
      WHEN LOWER(concepto) LIKE '%interes%' THEN 'intereses'
      ELSE 'mantenimiento_reparaciones' -- Default para varios
    END
  ELSE NULL
END
WHERE rdo_category_code IS NULL 
  AND deleted_at IS NULL;


-- 2. MAPEAR INSUMOS EXISTENTES (tipo_item)
-- =====================================================
-- Primero, inferir tipo_item basado en categoria_pl o nombre
UPDATE insumos
SET tipo_item = CASE
  -- Si categoria_pl contiene 'cmv' o 'hamburguesa' -> ingrediente
  WHEN LOWER(COALESCE(categoria_pl, '')) LIKE '%cmv%' THEN 'ingrediente'
  WHEN LOWER(COALESCE(categoria_pl, '')) LIKE '%hamburguesa%' THEN 'ingrediente'
  WHEN LOWER(COALESCE(categoria_pl, '')) LIKE '%bebida%' THEN 'ingrediente'
  -- Por nombre
  WHEN LOWER(nombre) LIKE '%carne%' OR LOWER(nombre) LIKE '%pan%' OR LOWER(nombre) LIKE '%queso%' THEN 'ingrediente'
  WHEN LOWER(nombre) LIKE '%bacon%' OR LOWER(nombre) LIKE '%cheddar%' OR LOWER(nombre) LIKE '%lechuga%' THEN 'ingrediente'
  WHEN LOWER(nombre) LIKE '%tomate%' OR LOWER(nombre) LIKE '%cebolla%' OR LOWER(nombre) LIKE '%pepino%' THEN 'ingrediente'
  WHEN LOWER(nombre) LIKE '%cerveza%' OR LOWER(nombre) LIKE '%gaseosa%' OR LOWER(nombre) LIKE '%agua%' THEN 'ingrediente'
  WHEN LOWER(nombre) LIKE '%mayonesa%' OR LOWER(nombre) LIKE '%ketchup%' OR LOWER(nombre) LIKE '%mostaza%' THEN 'ingrediente'
  WHEN LOWER(nombre) LIKE '%salsa%' THEN 'ingrediente'
  -- Descartables -> insumo
  WHEN LOWER(nombre) LIKE '%descartable%' OR LOWER(nombre) LIKE '%servilleta%' THEN 'insumo'
  WHEN LOWER(nombre) LIKE '%vaso%' OR LOWER(nombre) LIKE '%bolsa%' OR LOWER(nombre) LIKE '%caja%' THEN 'insumo'
  WHEN LOWER(nombre) LIKE '%contenedor%' OR LOWER(nombre) LIKE '%envase%' THEN 'insumo'
  WHEN LOWER(nombre) LIKE '%limpi%' OR LOWER(nombre) LIKE '%detergente%' OR LOWER(nombre) LIKE '%lavandina%' THEN 'insumo'
  WHEN LOWER(nombre) LIKE '%sobrecito%' OR LOWER(nombre) LIKE '%sachet%' THEN 'insumo'
  -- Default basado en si tiene unidad de peso/volumen (ingrediente) o unidad (insumo)
  WHEN unidad_base IN ('kg', 'g', 'lt', 'ml', 'cc') THEN 'ingrediente'
  ELSE 'insumo'
END
WHERE tipo_item IS NULL OR tipo_item = 'insumo';


-- 3. MAPEAR INSUMOS A CATEGORÍAS RDO
-- =====================================================
UPDATE insumos
SET rdo_category_code = CASE
  -- Ingredientes
  WHEN tipo_item = 'ingrediente' THEN
    CASE 
      WHEN LOWER(COALESCE(categoria_pl, nombre)) LIKE '%bebida%alcohol%' OR LOWER(nombre) LIKE '%cerveza%' OR LOWER(nombre) LIKE '%vino%' THEN 'cmv_bebidas_alcohol'
      WHEN LOWER(COALESCE(categoria_pl, nombre)) LIKE '%bebida%' OR LOWER(nombre) LIKE '%gaseosa%' OR LOWER(nombre) LIKE '%agua%' OR LOWER(nombre) LIKE '%jugo%' THEN 'cmv_bebidas_sin_alcohol'
      ELSE 'cmv_hamburguesas'
    END
  -- Insumos
  WHEN tipo_item = 'insumo' THEN
    CASE 
      WHEN LOWER(COALESCE(categoria_pl, nombre)) LIKE '%delivery%' OR LOWER(nombre) LIKE '%delivery%' THEN 'descartables_delivery'
      WHEN LOWER(nombre) LIKE '%sobrecito%' OR LOWER(nombre) LIKE '%sachet%' OR LOWER(nombre) LIKE '%mani%' THEN 'insumos_clientes'
      WHEN LOWER(nombre) LIKE '%limpi%' OR LOWER(nombre) LIKE '%higien%' OR LOWER(nombre) LIKE '%detergente%' THEN 'limpieza_higiene'
      WHEN LOWER(COALESCE(categoria_pl, nombre)) LIKE '%cocina%' AND LOWER(nombre) LIKE '%descart%' THEN 'descartables_cocina'
      ELSE 'descartables_salon'
    END
  ELSE NULL
END
WHERE rdo_category_code IS NULL 
  AND deleted_at IS NULL;


-- 4. CONFIGURAR tracks_stock PARA INGREDIENTES
-- =====================================================
UPDATE insumos
SET tracks_stock = CASE
  WHEN tipo_item = 'ingrediente' THEN true
  -- Algunos insumos también se trackean
  WHEN LOWER(nombre) LIKE '%descartable%delivery%' THEN true
  WHEN LOWER(nombre) LIKE '%caja%' AND LOWER(nombre) LIKE '%delivery%' THEN true
  ELSE false
END
WHERE tracks_stock IS NULL;


-- 5. ACTUALIZAR PROVEEDORES CON TIPO
-- =====================================================
-- Inferir tipo de proveedor basado en los insumos que provee
UPDATE proveedores p
SET tipo_proveedor = ARRAY(
  SELECT DISTINCT i.tipo_item
  FROM insumos i
  WHERE i.proveedor_sugerido_id = p.id 
     OR i.proveedor_obligatorio_id = p.id
)
WHERE tipo_proveedor IS NULL OR array_length(tipo_proveedor, 1) IS NULL;

-- Si no tiene insumos asociados, marcar como servicio (asumiendo proveedor de servicios)
UPDATE proveedores
SET tipo_proveedor = ARRAY['servicio']::text[]
WHERE tipo_proveedor IS NULL OR array_length(tipo_proveedor, 1) IS NULL;


-- 6. ACTUALIZAR items_factura CON CATEGORÍA RDO
-- =====================================================
-- Heredar la categoría del insumo
UPDATE items_factura it
SET rdo_category_code = i.rdo_category_code
FROM insumos i
WHERE it.insumo_id = i.id
  AND it.rdo_category_code IS NULL
  AND i.rdo_category_code IS NOT NULL;


-- 7. REPORTE DE MIGRACIÓN
-- =====================================================
DO $$
DECLARE
  gastos_migrados int;
  gastos_sin_migrar int;
  insumos_migrados int;
  insumos_sin_migrar int;
  items_migrados int;
BEGIN
  SELECT COUNT(*) INTO gastos_migrados FROM gastos WHERE rdo_category_code IS NOT NULL AND deleted_at IS NULL;
  SELECT COUNT(*) INTO gastos_sin_migrar FROM gastos WHERE rdo_category_code IS NULL AND deleted_at IS NULL;
  SELECT COUNT(*) INTO insumos_migrados FROM insumos WHERE rdo_category_code IS NOT NULL AND deleted_at IS NULL;
  SELECT COUNT(*) INTO insumos_sin_migrar FROM insumos WHERE rdo_category_code IS NULL AND deleted_at IS NULL;
  SELECT COUNT(*) INTO items_migrados FROM items_factura WHERE rdo_category_code IS NOT NULL;
  
  RAISE NOTICE '========================================';
  RAISE NOTICE 'REPORTE DE MIGRACIÓN RDO';
  RAISE NOTICE '========================================';
  RAISE NOTICE 'Gastos migrados: %', gastos_migrados;
  RAISE NOTICE 'Gastos sin migrar: %', gastos_sin_migrar;
  RAISE NOTICE 'Insumos migrados: %', insumos_migrados;
  RAISE NOTICE 'Insumos sin migrar: %', insumos_sin_migrar;
  RAISE NOTICE 'Items factura migrados: %', items_migrados;
  RAISE NOTICE '========================================';
END $$;
